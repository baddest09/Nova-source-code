package com.example.novahealthcareuser

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
