package com.nova.healthcareuser

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
