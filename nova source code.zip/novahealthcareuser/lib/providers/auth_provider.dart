// ignore_for_file: unused_local_variable

import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../router/app_router.dart';
import '../services/auth_error_handler.dart';
import '../utils/app_constants.dart';
import '../utils/navigates.dart';
import '../utils/shared_preference.dart';
import '../utils/snackbar.dart';

class AuthProvider extends ChangeNotifier {
  bool isLoading = false;

  void loading(bool status) {
    isLoading = status;
    notifyListeners();
  }

  Future registration(String email, String password, String name) async {
    try {
      loading(true);
      UserCredential userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(email: email, password: password);

      final userId = userCredential.user!.uid;
      await saveuser(userId, "", name, email);
      setStringValue(AppConstants.USERID, userId);
      customPushAndRemoveUntill(AppRoutes.NAVIG);
    } on FirebaseAuthException catch (e) {
      NotificationsService.showSnackbar(firebaseAuthHandler(e.code));
    } catch (e) {
      NotificationsService.showSnackbar("Error $e");
    } finally {
      loading(false);
    }
  }

  Future<void> tokenCreation(String userid) async {
    String? token = await FirebaseMessaging.instance.getToken();
    await FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .update({"noti_token": token});

    await setStringValue("token", token!);
  }

  void sigin(String email, String password) async {
    try {
      loading(true);
      final userCredential = await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: email, password: password);
      await tokenCreation(userCredential.user!.uid);
      setStringValue(AppConstants.USERID, userCredential.user!.uid);
      customPushAndRemoveUntill(AppRoutes.NAVIG);
    } on FirebaseAuthException catch (e) {
      NotificationsService.showSnackbar(firebaseAuthHandler(e.code));
    } catch (e) {
      NotificationsService.showSnackbar("Error $e");
    } finally {
      loading(false);
    }
  }

  // GOOGLE SIGIN

  Future signInWithGoogle() async {
    final GoogleSignIn googleSignIn = GoogleSignIn();

    final GoogleSignInAccount? googleSignInAccount =
        await googleSignIn.signIn();

    if (googleSignInAccount != null) {
      final GoogleSignInAuthentication googleSignInAuthentication =
          await googleSignInAccount.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleSignInAuthentication.accessToken,
        idToken: googleSignInAuthentication.idToken,
      );

      try {
        final UserCredential userCredential =
            await FirebaseAuth.instance.signInWithCredential(credential);

        final data = await FirebaseFirestore.instance
            .collection("users")
            .doc(userCredential.user!.uid)
            .get();
        if (!data.exists) {
          await saveuser(userCredential.user!.uid, "",
              userCredential.user!.displayName!, userCredential.user!.email!);

          await tokenCreation(userCredential.user!.uid);
          setStringValue(AppConstants.USERID, userCredential.user!.uid);
          customPushAndRemoveUntill(AppRoutes.NAVIG);
        } else {
          bool checkROle = await checkRole(userCredential.user!.uid);

          if (checkROle) {
            await tokenCreation(userCredential.user!.uid);
            setStringValue(AppConstants.USERID, userCredential.user!.uid);
            customPushAndRemoveUntill(AppRoutes.NAVIG);
          }
        }
      } on FirebaseAuthException catch (e) {
        NotificationsService.showSnackbar(firebaseAuthHandler(e.code));
      } catch (e) {
        NotificationsService.showSnackbar("Error $e");
      } finally {
        loading(false);
      }
    }
  }

  Future saveuser(String uid, String phone, String name, String email) async {
    try {
      Map<String, dynamic> userdata = {
        "userid": uid,
        "role": "patient",
        'name': name,
        'email': email,
        'phone': phone,
        'image': "http://pngimg.com/uploads/doctor/doctor_PNG16041.png",
        "noti_token": "",
        "location": ""
      };

      await FirebaseFirestore.instance
          .collection("users")
          .doc(uid)
          .set(userdata, SetOptions(merge: true));

      await tokenCreation(uid);
    } catch (e) {
      NotificationsService.showSnackbar("Error $e");
    }
  }

  // check user when app start (Splash screen)

  void checkauthState() async {
    String userid = await getStringValue(AppConstants.USERID);
    bool isLangSelected = await getBoolValue(AppConstants.ISLANGUAGESELECTED);
    debugPrint("USERID---> $userid");
    debugPrint("ISLANGSELECTED---> $isLangSelected");

    await Future.delayed(const Duration(seconds: 3));

    if (isLangSelected == false) {
      customPushAndRemoveUntill(AppRoutes.SELECTLANGUAGE);
    } else if (userid == "") {
      customPushAndRemoveUntill(AppRoutes.LOGINTYPE);
    } else {
      customPushAndRemoveUntill(AppRoutes.NAVIG);
    }
  }

  void successLogin(String userid, String phone) async {
    final data =
        await FirebaseFirestore.instance.collection("users").doc(userid).get();
    if (!data.exists) {
      await saveuser(userid, phone, "", "");

      await tokenCreation(userid);
      await setStringValue(AppConstants.USERID, userid);
      customPushAndRemoveUntill(AppRoutes.NAVIG);
    } else {
      bool checkROle = await checkRole(userid);

      if (checkROle) {
        await tokenCreation(userid);
        await setStringValue(AppConstants.USERID, userid);
        customPushAndRemoveUntill(AppRoutes.NAVIG);
      }
    }
  }

  checkRole(String userId) async {
    final data =
        await FirebaseFirestore.instance.collection("users").doc(userId).get();
    if (data.get("role") == 'patient') {
      return true;
    } else {
      final GoogleSignIn googleSignIn = GoogleSignIn();
      removeAll();
      googleSignIn.signOut();
      FirebaseAuth.instance.signOut();
      NotificationsService.showSnackbar(
          "Account is linked with nova health care doctor");
      return false;
    }
  }

  void signout() {
    final GoogleSignIn googleSignIn = GoogleSignIn();
    removeAll();
    isLoading = false;
    googleSignIn.signOut();
    FirebaseAuth.instance.signOut();
    customPushAndRemoveUntill(AppRoutes.LOGINTYPE);
  }
}
