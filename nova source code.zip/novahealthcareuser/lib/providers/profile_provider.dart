// ignore_for_file: unused_local_variable

import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:doctoworld_doctor/utils/app_constants.dart';
import 'package:doctoworld_doctor/utils/shared_preference.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

class ProfileProvider extends ChangeNotifier {
  bool isLoading = true;
  String imageUrl = "";
  String name = "";
  String email = "";
  String phone = "";

  // Update Fields
  // Logo
  File? logo;
  String logoUrl = "";

  void loading(bool state) {
    isLoading = state;
    notifyListeners();
  }

  void getCurrentUser() async {
    loading(true);
    String userid = await getStringValue(AppConstants.USERID);
    final doc =
        FirebaseFirestore.instance.collection("users").doc(userid).get();
    doc.then((value) {
      imageUrl = value.get("image");
      name = value.get("name") ?? "";
      email = value.get("email") ?? "";
      phone = value.get("phone") ?? "";

      loading(false);
      notifyListeners();
    });
  }

  Future pickLogo() async {
    FilePickerResult? result =
        await FilePicker.platform.pickFiles(type: FileType.image);

    if (result != null) {
      logo = File(result.files.single.path!);
      notifyListeners();
    } else {
      // User canceled the picker
    }
  }

  Future uploadLogo() async {
    try {
      String userid = await getStringValue(AppConstants.USERID);
      final ref = FirebaseStorage.instance.ref().child('profileimages/$userid');

      await ref.putFile(logo!).whenComplete(() async {
        await ref.getDownloadURL().then((value) {
          logoUrl = value;
        });
      });
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  void updateProfile(
    String name,
    String email,
    String phone,
  ) async {
    loading(true);
    String userid = await getStringValue(AppConstants.USERID);
    if (logo != null) {
      await uploadLogo();
      await FirebaseFirestore.instance.collection("users").doc(userid).set(
        {
          "name": name,
          "email": email,
          "phone": phone,
          "image": logoUrl,
        },
        SetOptions(merge: true),
      );
    } else {
      await FirebaseFirestore.instance.collection("users").doc(userid).set(
        {
          "name": name,
          "email": email,
          "phone": phone,
        },
        SetOptions(merge: true),
      );
    }

    // Calling get user method to get updated data
    getCurrentUser();
    imageUrl = "";
    logo = null;
    loading(false);
  }
}
