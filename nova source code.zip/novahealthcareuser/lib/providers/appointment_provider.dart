// ignore_for_file: unused_local_variable

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:doctoworld_doctor/models/call_model.dart';
import 'package:doctoworld_doctor/utils/shared_preference.dart';
import 'package:doctoworld_doctor/utils/snackbar.dart';
import 'package:flutter/material.dart';
import 'package:one_context/one_context.dart';
import 'package:uuid/uuid.dart';
import '../AppMenu/Appointment/call_sceen.dart';
import '../router/app_router.dart';
import '../services/notificationapis.dart';
import '../utils/navigates.dart';
import 'package:collection/collection.dart';

class AppointmentProvider extends ChangeNotifier {
  CollectionReference collectionCalls =
      FirebaseFirestore.instance.collection("calls");
  CollectionReference collectionCodes =
      FirebaseFirestore.instance.collection("codes");
  bool isLoading = true;
  List appointmentList = [];

  List chatList = [];

  String selectedDocId = "";
  String selectedUserId = "";

  void loading(bool state) {
    isLoading = state;
    notifyListeners();
  }

  void geappointments() async {
    loading(true);
    String userid = await getStringValue("userid");
    CollectionReference col =
        FirebaseFirestore.instance.collection("appointment");

    col.where("userid", isEqualTo: userid).snapshots().listen((event) {
      appointmentList = event.docs;
      loading(false);
      notifyListeners();
    });
  }

  bookAppointment(String doctorid, String doctorName, String date, String time,
      String purpose, String name) async {
    String userid = await getStringValue("userid");
    FirebaseFirestore.instance.collection("appointment").add({
      "userid": userid,
      "doctorid": doctorid,
      "doctorname": doctorName,
      "date": date,
      "time": time,
      "purpose": purpose,
      "name": name,
      // "phone": phone,
      "status": "pending",
      "rating": 0.0,
      "ratingstatus": false
    });
    await sendNotiToDoctor("New appointment from $name", doctorid);
    NotificationsService.showSnackbar("Your apppointment is booked");
    customPushAndRemoveUntill(AppRoutes.appointmentBookedPage);
  }

// when user appoint the doctor booking
  Future sendNotiToDoctor(String message, String docid) async {
    final data =
        await FirebaseFirestore.instance.collection("users").doc(docid).get();
    String token = data.get("noti_token");
    sendPushMessage(token, message, "Attention Doctor");
  }

  getAllChats(String userId, String peerId) async {
    loading(true);
    String chatId;
    if (userId.compareTo(peerId) > 0) {
      chatId = '$userId-$peerId';
    } else {
      chatId = '$peerId-$userId';
    }

    final data =
        await FirebaseFirestore.instance.collection("chats").doc(chatId).get();

    if (!data.exists) {
      FirebaseFirestore.instance.collection("chats").doc(chatId).set({
        "pathid": chatId,
        "timestamp": DateTime.now().millisecondsSinceEpoch,
      });
    }

    FirebaseFirestore.instance
        .collection("chats")
        .doc(chatId)
        .collection("messages")
        .orderBy("timestamp", descending: true)
        .snapshots()
        .listen((event) {
      chatList = event.docs;
      loading(false);
    });
  }

  sendChat(String ms, String userId, String peerId) async {
    if (ms.isNotEmpty) {
      String chatId;
      if (userId.compareTo(peerId) > 0) {
        chatId = '$userId-$peerId';
      } else {
        chatId = '$peerId-$userId';
      }

      await FirebaseFirestore.instance
          .collection("chats")
          .doc(chatId)
          .collection("messages")
          .add({
        "senderId": userId,
        "receiverId": peerId,
        "timestamp": DateTime.now().millisecondsSinceEpoch,
        "message": ms
      });
    }
    await sendNotiToUser(ms, peerId);
  }

  Future sendNotiToUser(String message, String peerId) async {
    final data =
        await FirebaseFirestore.instance.collection("users").doc(peerId).get();
    String token = data.get("noti_token");
    sendPushMessage(token, message, "New message");
  }

  saveReview(double rating, String userid, String doctorid, String review,
      String appointmentid, String purpose, String username) async {
    await FirebaseFirestore.instance.collection("reviews").add({
      "userid": userid,
      "doctorid": doctorid,
      "rating": rating,
      "review": review,
      "name": username,
      "purpose": purpose,
      "datetime": DateTime.now()
    });

    await FirebaseFirestore.instance
        .collection("appointment")
        .doc(appointmentid)
        .update({
      "ratingstatus": true,
    });

    await FirebaseFirestore.instance
        .collection("appointment")
        .doc(appointmentid)
        .update({
      "rating": rating,
    });

    // calculate rating average

    CollectionReference col = FirebaseFirestore.instance.collection("reviews");
    List ratings = [];
    List<double> star = [];
    final data = await col.where("doctorid", isEqualTo: doctorid).get();

    for (var i = 0; i < data.docs.length; i++) {
      star.add(data.docs[i]["rating"]);
    }

    final star2 = star;
    final ave = star2.average;

    FirebaseFirestore.instance
        .collection("users")
        .doc(doctorid)
        .update({"rating": ave.roundToDouble()});
  }

  /// video call
  ///
  ///

  Future<void> createCall() async {
    final String uniqueId = const Uuid().v1();

    final Call senderCall = Call(
      callerId: selectedUserId,
      callerName: "Patient",
      // callerPic: "pic",
      receiverId: selectedDocId,
      receiverName: "Doctor",
      // receiverPic: "REpic",
      callId: uniqueId,
      hasDialled: true,
    );

    final Call receiverCall = Call(
      callerId: selectedUserId,
      callerName: "Patient",
      // callerPic: "pic",
      receiverId: selectedDocId,
      receiverName: "Doctor",
      // receiverPic: "REpic",
      callId: uniqueId,
      hasDialled: false,
    );
    await collectionCalls.doc(senderCall.callerId).set(senderCall.toMap());

    await collectionCalls
        .doc(receiverCall.receiverId)
        .set(receiverCall.toMap());

    await sendNotiToDoctorForCalling(
        "Your patient is calling you", selectedDocId);

    OneContext().push(
        MaterialPageRoute(builder: (_) => CallScreen(channelId: uniqueId)));
  }

  Future<void> endCall() async {
    await collectionCalls.doc(selectedDocId).delete();
    await collectionCalls.doc(selectedUserId).delete();
  }

  // when calling
  Future sendNotiToDoctorForCalling(String message, String docid) async {
    final data =
        await FirebaseFirestore.instance.collection("users").doc(docid).get();
    String token = data.get("noti_token");
    sendPushMessage(token, message, "Calling");
  }

  ///////// APPOINTMENT BY CODE

  //check code exist or not

  checkCode(String code, String doctorid, String doctorName, String date,
      String time, String purpose, String name) async {
    final data =
        await collectionCodes.where("code", isEqualTo: code).limit(1).get();

    if (data.docs.isEmpty) {
      NotificationsService.showSnackbar(
          "Invalid code! please enter valid code");
    } else {
      bookAppointment(doctorid, doctorName, date, time, purpose, name);
      collectionCodes.doc(data.docs.first.id).delete();
    }
  }
}
