// ignore_for_file: unused_local_variable, unused_field

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:doctoworld_doctor/utils/shared_preference.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:location/location.dart';
import 'package:geocoding/geocoding.dart' as geo;
import 'package:one_context/one_context.dart';

class DoctorsProvider extends ChangeNotifier {
  bool isLoading = true;
  List doctorList = [];

  String doctorNameSelected = "";
  String doctorIdSelected = "";

  void loading(bool state) {
    isLoading = state;
    notifyListeners();
  }

  void getDoctors() {
    loading(true);

    CollectionReference col = FirebaseFirestore.instance.collection("users");

    col.where("role", isEqualTo: 'doctor').snapshots().listen((event) {
      doctorList = event.docs;
      loading(false);
      notifyListeners();
    });
  }

  getDoctorImage(String doctorId) {
    int index = doctorList.indexWhere((element) => element.id == doctorId);

    return doctorList[index]["image"];
  }

//// Location
  ///

  LocationData? _location;
  String? error;
  String address = "Location";
  Future<void> getLocation() async {
    error = null;
    try {
      bool dialogViewed = await getBoolValue("locationdialogview");
      if (dialogViewed == false) {
        locationDialog();
      }
      Location location = Location();

      bool serviceEnabled;
      PermissionStatus permissionGranted;

      serviceEnabled = await location.serviceEnabled();
      if (!serviceEnabled) {
        serviceEnabled = await location.requestService();
        if (!serviceEnabled) {
          return;
        }
      }

      permissionGranted = await location.hasPermission();
      if (permissionGranted == PermissionStatus.denied) {
        permissionGranted = await location.requestPermission();
        if (permissionGranted != PermissionStatus.granted) {
          return;
        }
      }

      LocationData locationData = await location.getLocation();
      List<geo.Placemark> placemarks = await geo.placemarkFromCoordinates(
          locationData.latitude!, locationData.longitude!);
      _location = locationData;
      address =
          '${placemarks.first.street}, ${placemarks.first.subLocality}, ${placemarks.first.subAdministrativeArea}, ${placemarks.first.postalCode}';
      address = placemarks.first.locality!;
      debugPrint(address);
      notifyListeners();
    } on PlatformException catch (err) {
      error = err.code;
    }
  }

  Future<void> locationDialog() async {
    // example dialog
    await OneContext().showDialog(
        // barrierDismissible: false,
        builder: (_) => CupertinoAlertDialog(
              actions: [
                CupertinoDialogAction(
                    onPressed: () {
                      setBoolValue("locationdialogview", true);
                      Navigator.of(_, rootNavigator: true).pop();
                    },
                    child: const Text("Ok")),
              ],
              title: const Text("Use location service"),
              content: const Text(
                  "Nova Healthcare collects location data to enable location tracking even when the app is closed or not in use"),
            ));
  }
}
