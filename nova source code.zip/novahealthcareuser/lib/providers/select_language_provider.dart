// ignore_for_file: unused_local_variable

import 'package:doctoworld_doctor/router/app_router.dart';
import 'package:doctoworld_doctor/utils/app_constants.dart';
import 'package:doctoworld_doctor/utils/navigates.dart';
import 'package:doctoworld_doctor/utils/shared_preference.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class SelectLanguageProvider extends ChangeNotifier {
  String currentLocale = "en";

  void getCurrentLocale(BuildContext context) {
    currentLocale = context.locale.languageCode;
    notifyListeners();
  }

  void changeLocal(BuildContext context, String locale,
      {bool isContinue = false}) async {
    await context.setLocale(Locale(locale));
    currentLocale = locale;
    setBoolValue(AppConstants.ISLANGUAGESELECTED, true);
    notifyListeners();

    if (isContinue == true) {
      String userid = await getStringValue(AppConstants.USERID);
      if (userid == "") {
        customPushAndRemoveUntill(AppRoutes.LOGINTYPE);
      } else {
        customPushAndRemoveUntill(AppRoutes.NAVIG);
      }
    }
  }
}
