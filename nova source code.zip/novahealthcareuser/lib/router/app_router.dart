// ignore_for_file: constant_identifier_names

import 'package:doctoworld_doctor/AppMenu/Appointment/chat_page.dart';
import 'package:doctoworld_doctor/AppMenu/OurDepartments/doctor_department.dart';
import 'package:doctoworld_doctor/views/Register/phone_register.dart';
import 'package:doctoworld_doctor/views/select_language.dart';
import 'package:flutter/material.dart';
import '../AppMenu/Account/profile_page.dart';
import '../AppMenu/ContactUs/contact_us.dart';
import '../AppMenu/OurDepartments/our_departments.dart';
import '../AppMenu/OurDoctors/appointment_booked.dart';
import '../AppMenu/OurDoctors/book_appointment.dart';
import '../AppMenu/OurDoctors/doctor_review.dart';
import '../AppMenu/OurDoctors/list_of_doctors.dart';
import '../AppMenu/OurDoctors/our_doctors.dart';
import '../AppMenu/app_menu.dart';

import '../views/Login/email_login.dart';
import '../views/Login/login_types.dart';
import '../views/Login/phone_login.dart';
import '../views/Register/email_register.dart';
import '../views/Register/register_types.dart';
import '../views/navig.dart';
import '../views/splash.dart';

class AppRoutes {
  static const SPLASH = '/';
  static const LOGIN = '/login';
  static const SELECTLANGUAGE = '/selectlanguage';
  static const NAVIG = '/navig';
  static const homePage = 'home_page';
  static const appMenu = 'app_menu';
  static const ourDoctorsPage = 'our_doctors';
  static const listOfDoctors = 'list_of_doctors';
  // static const doctorInfoPage = 'doctor_info';
  static const doctorReviewPage = 'doctor_review';
  static const bookAppointmentPage = 'book_appointment';
  static const appointmentBookedPage = 'appointment_booked';
  static const ourDepartmentsPage = 'our_departments';
  static const doctorDepartmentsPage = 'doctor_department';
  static const pharmacyNearMe = 'pharmacy_near_me';
  static const contactUsPage = 'contact_us';

  static const PROFILE = '/profile';
  static const SUPPORT = '/support';
  static const CHATSCREEN = '/chatscreen';

  static const EMAILLOGIN = '/emaillogin';
  static const PHONELOGIN = '/phonelogin';
  static const REGISTERTYPE = '/registertype';

  static const PHONEREGISTER = '/phoneregister';
  static const EMAILREGISTER = '/emailregister';
  static const VERIFYPHONE = '/verifyphone';
  static const LOGINTYPE = '/logintype';

  static const UNKNOWN = '404';

  static Map<String, Widget Function(BuildContext)> getAppRoutes() {
    Map<String, Widget Function(BuildContext)> appRoutes = {
      SPLASH: (BuildContext context) => const Splash(),

      SELECTLANGUAGE: (BuildContext context) => const SelectLanguage(),
      NAVIG: (BuildContext context) => const Navig(),
      appMenu: (context) => const AppMenu(),
      ourDoctorsPage: (context) => const OurDoctors(),
      listOfDoctors: (context) => const DoctorsPage(),
      // doctorInfoPage: (context) => const DoctorInfo(),
      doctorReviewPage: (context) => const DoctorReviewPage(),
      bookAppointmentPage: (context) => const BookAppointmentPage(),
      appointmentBookedPage: (context) => const AppointmentBooked(),
      ourDepartmentsPage: (context) => const OurDepartments(),
      doctorDepartmentsPage: (context) => const DoctorsDepartmentsPage(),
      contactUsPage: (context) => const ContactUsPage(),

      PROFILE: (BuildContext context) => const ProfilePage(),
      CHATSCREEN: (BuildContext context) => const Chat(),
      EMAILLOGIN: (BuildContext context) => EmailLogin(),
      PHONELOGIN: (BuildContext context) => PhoneLogin(),
      REGISTERTYPE: (BuildContext context) => const RegisterTypes(),
      PHONEREGISTER: (BuildContext context) => PhoneRegister(),
      LOGINTYPE: (BuildContext context) => const LoginTypes(),
      EMAILREGISTER: (BuildContext context) => RegisterEmail(),

      // SUPPORT: (BuildContext context) => const SupportPage(),
    };
    return appRoutes;
  }
}
