import 'package:doctoworld_doctor/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';

class Splash extends StatefulWidget {
  const Splash({Key? key}) : super(key: key);

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();

    Provider.of<AuthProvider>(context, listen: false).checkauthState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kMainColor,
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: Column(
          children: [
            const Spacer(),
            Center(
              child: Image.asset(
                "assets/doctor_logo.png",
                width: 230,
              ),
            ),
            const Spacer(),
            Center(
              child: Image.asset(
                "assets/hero_image.png",
                width: 250,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
