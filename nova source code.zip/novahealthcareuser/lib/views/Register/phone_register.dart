// ignore_for_file: must_be_immutable

import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/translations/locale_keys.g.dart';
import 'package:doctoworld_doctor/utils/snackbar.dart';
import 'package:doctoworld_doctor/views/verify_phone.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_field/phone_number.dart';
import 'package:one_context/one_context.dart';
import '../../widgets/text_fields.dart';

class PhoneRegister extends StatelessWidget {
  PhoneRegister({super.key});

  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();

  String phone = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.chevron_left)),
        title: Text(LocaleKeys.registerNow.tr(),
            style: Theme.of(context)
                .textTheme
                .bodyText2!
                .copyWith(fontSize: 17, fontWeight: FontWeight.w700)),
        centerTitle: true,
      ),
      body: FadedSlideAnimation(
        beginOffset: const Offset(0, 0.3),
        endOffset: const Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
        child: ListView(padding: const EdgeInsets.all(20), children: [
          const SizedBox(
            height: 53,
          ),
          const SizedBox(height: 20.0),
          IntlPhoneField(
            onChanged: (PhoneNumber number) {
              phone = number.completeNumber;
            },
            initialValue: _phoneController.text,
            controller: _phoneController,
            initialCountryCode: 'UG',
            // keyboardType: const TextInputType.numberWithOptions(
            //     signed: true, decimal: true),
            decoration: InputDecoration(
                hintText: 'Phone number',
                hintStyle: Theme.of(context)
                    .textTheme
                    .bodyText1!
                    .copyWith(color: Colors.grey, fontSize: 15),
                filled: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                )),
          ),
          const SizedBox(height: 20.0),
          EntryField3(
            hint: LocaleKeys.fullName.tr(),
            prefixIcon: Icons.person,
            controller: _nameController,
          ),
          const SizedBox(height: 20.0),
          EntryField3(
            hint: LocaleKeys.enteremail.tr(),
            prefixIcon: Icons.email,
            controller: _emailController,
          ),
          const SizedBox(height: 30.0),
          SizedBox(
            width: 260,
            height: 50,
            child: ElevatedButton(
                child: const Text("Proceed",
                    style: TextStyle(color: Colors.white, fontSize: 21)),
                onPressed: () async {
                  if (phone.startsWith("+") == true) {
                    OneContext().push(MaterialPageRoute(
                        builder: (_) => VerifyPhoneNumberScreen(
                              phone: phone,
                              isLogin: false,
                              email: _emailController.text.trim(),
                              name: _nameController.text.trim(),
                            )));
                  } else {
                    NotificationsService.showSnackbar(
                        "Number must start with country code e.g +971");
                  }
                }),
          ),
          const SizedBox(
            height: 20,
          ),
        ]),
      ),
    );
  }
}
