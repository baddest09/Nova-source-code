import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/router/app_router.dart';
import 'package:doctoworld_doctor/utils/colors.dart';
import 'package:doctoworld_doctor/utils/navigates.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:social_login_buttons/social_login_buttons.dart';

import '../../providers/auth_provider.dart';

class RegisterTypes extends StatelessWidget {
  const RegisterTypes({super.key});

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      body: FadedSlideAnimation(
        beginOffset: const Offset(0, 0.3),
        endOffset: const Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
        child: SingleChildScrollView(
          child: Stack(
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                height: size.height * 0.6,
                color: Theme.of(context).backgroundColor,
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Spacer(),
                    Expanded(
                        flex: 2, child: Image.asset('assets/doctor_logo.png')),
                    const Spacer(),
                    Expanded(
                        flex: 4, child: Image.asset('assets/hero_image.png')),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    SizedBox(height: size.height * 0.52),
                    SocialLoginButton(
                      imageWidth: 30,
                      imageURL:
                          "https://cdn-icons-png.flaticon.com/512/893/893247.png",
                      backgroundColor: Colors.red,
                      text: 'Signup with email',
                      buttonType: SocialLoginButtonType.generalLogin,
                      onPressed: () {
                        customPush(AppRoutes.EMAILREGISTER);
                      },
                    ),
                    const SizedBox(height: 15.0),
                    SocialLoginButton(
                      imageWidth: 30,
                      imageURL:
                          "https://cdn-icons-png.flaticon.com/512/684/684911.png",
                      backgroundColor: primaryColor,
                      text: 'Signup with phone',
                      buttonType: SocialLoginButtonType.generalLogin,
                      onPressed: () {
                        customPush(AppRoutes.PHONEREGISTER);
                      },
                    ),
                    const SizedBox(height: 15.0),
                    SocialLoginButton(
                      buttonType: SocialLoginButtonType.google,
                      text: "Signup with google",
                      onPressed: () {
                        context.read<AuthProvider>().signInWithGoogle();
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
