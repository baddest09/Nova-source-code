import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/providers/auth_provider.dart';
import 'package:doctoworld_doctor/translations/locale_keys.g.dart';
import 'package:easy_localization/easy_localization.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../widgets/text_fields.dart';

class RegisterEmail extends StatelessWidget {
  RegisterEmail({super.key});

  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.chevron_left)),
        title: Text(LocaleKeys.registerNow.tr(),
            style: Theme.of(context)
                .textTheme
                .bodyText2!
                .copyWith(fontSize: 17, fontWeight: FontWeight.w700)),
        centerTitle: true,
      ),
      body: FadedSlideAnimation(
        beginOffset: const Offset(0, 0.3),
        endOffset: const Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(
              height: 3,
            ),
            const SizedBox(
              height: 53,
            ),
            const SizedBox(height: 20.0),
            EntryField3(
              controller: _nameController,
              prefixIcon: Icons.person,
              hint: LocaleKeys.fullName.tr(),
            ),
            const SizedBox(height: 20.0),
            EntryField3(
              controller: _emailController,
              prefixIcon: Icons.mail,
              hint: LocaleKeys.emailAddress.tr(),
            ),
            const SizedBox(height: 20.0),
            EntryField3(
              controller: _passController,
              prefixIcon: Icons.password,
              hint: LocaleKeys.enterpass.tr(),
            ),
            const SizedBox(height: 30.0),
            SizedBox(
              width: 260,
              height: 50,
              child: ElevatedButton(
                  child: Text(LocaleKeys.signup.tr(),
                      style:
                          const TextStyle(color: Colors.white, fontSize: 21)),
                  onPressed: () async {
                    if (_emailController.text.isNotEmpty &&
                        _passController.text.isNotEmpty &&
                        _nameController.text.isNotEmpty) {
                      context.read<AuthProvider>().registration(
                          _emailController.text.trim(),
                          _passController.text.trim(),
                          _nameController.text.trim());
                    }
                  }),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
