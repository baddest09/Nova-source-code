// ignore_for_file: use_build_context_synchronously

import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:doctoworld_doctor/providers/auth_provider.dart';
import 'package:doctoworld_doctor/utils/colors.dart';
import 'package:firebase_phone_auth_handler/firebase_phone_auth_handler.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../router/app_router.dart';
import '../utils/app_constants.dart';
import '../utils/navigates.dart';
import '../utils/shared_preference.dart';
import '../utils/snackbar.dart';
import '../widgets/loading.dart';
import '../widgets/pin_input.dart';

class VerifyPhoneNumberScreen extends StatefulWidget {
  final String phone;
  final String? email;
  final String? name;
  final bool isLogin;
  const VerifyPhoneNumberScreen({
    Key? key,
    required this.phone,
    required this.isLogin,
    this.email,
    this.name,
  }) : super(key: key);

  @override
  State<VerifyPhoneNumberScreen> createState() =>
      _VerifyPhoneNumberScreenState();
}

class _VerifyPhoneNumberScreenState extends State<VerifyPhoneNumberScreen>
    with WidgetsBindingObserver {
  bool isKeyboardVisible = false;

  late final ScrollController scrollController;

  @override
  void initState() {
    super.initState();

    scrollController = ScrollController();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    scrollController.dispose();
    super.dispose();
  }

  @override
  void didChangeMetrics() {
    final bottomViewInsets = WidgetsBinding.instance.window.viewInsets.bottom;
    isKeyboardVisible = bottomViewInsets > 0;
  }

  // scroll to bottom of screen, when pin input field is in focus.
  Future<void> _scrollToBottomOnKeyboardOpen() async {
    while (!isKeyboardVisible) {
      await Future.delayed(const Duration(milliseconds: 50));
    }

    await Future.delayed(const Duration(milliseconds: 250));

    await scrollController.animateTo(
      scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeIn,
    );
  }

  @override
  Widget build(BuildContext context) {
    return FirebasePhoneAuthProvider(
      child: FirebasePhoneAuthHandler(
        phoneNumber: widget.phone,
        signOutOnSuccessfulVerification: false,
        linkWithExistingUser: false,
        autoRetrievalTimeOutDuration: const Duration(seconds: 60),
        otpExpirationDuration: const Duration(seconds: 60),
        onCodeSent: () {
          log('OTP sent!');
        },
        onLoginSuccess: (userCredential, autoVerified) async {
          log(
            autoVerified
                ? 'OTP was fetched automatically!'
                : 'OTP was verified manually!',
          );
          NotificationsService.showSnackbar(
              'Phone number verified successfully!');

          log(
            'Login Success UID: ${userCredential.user?.uid}',
          );

          if (widget.isLogin == false) {
            final data = await FirebaseFirestore.instance
                .collection("users")
                .doc(userCredential.user!.uid)
                .get();
            if (!data.exists) {
              context.read<AuthProvider>().saveuser(userCredential.user!.uid,
                  widget.phone, widget.name!, widget.email!);
            }
          }
          await context
              .read<AuthProvider>()
              .tokenCreation(userCredential.user!.uid);
          setStringValue(AppConstants.USERID, userCredential.user!.uid);
          customPushAndRemoveUntill(AppRoutes.NAVIG);
        },
        onLoginFailed: (authException, stackTrace) {
          log(
            authException.message.toString(),
            error: authException,
            stackTrace: stackTrace,
          );

          switch (authException.code) {
            case 'invalid-phone-number':
              // invalid phone number
              return NotificationsService.showSnackbar('Invalid phone number!');
            case 'invalid-verification-code':
              // invalid otp entered
              return NotificationsService.showSnackbar(
                  'The entered OTP is invalid!');
            // handle other error codes
            default:
              NotificationsService.showSnackbar('Something went wrong!');
            // handle error further if needed
          }
        },
        onError: (error, stackTrace) {
          log(
            "",
            error: error,
            stackTrace: stackTrace,
          );

          NotificationsService.showSnackbar('An error occurred!');
        },
        builder: (context, controller) {
          return Scaffold(
            appBar: AppBar(
              leadingWidth: 0,
              leading: const SizedBox.shrink(),
              title: const Text("Verify Phone"),
              actions: [
                if (controller.codeSent)
                  TextButton(
                    onPressed: controller.isOtpExpired
                        ? () async {
                            log('Resend OTP');
                            await controller.sendOTP();
                          }
                        : null,
                    child: Text(
                      controller.isOtpExpired
                          ? "Resend"
                          : '${controller.otpExpirationTimeLeft.inSeconds}s',
                      style: const TextStyle(color: Colors.blue, fontSize: 18),
                    ),
                  ),
                const SizedBox(width: 5),
              ],
            ),
            body: controller.isSendingCode
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: const [
                      Loading(),
                      SizedBox(height: 50),
                      Center(
                        child: Text(
                          "Sending OTP",
                          style: TextStyle(fontSize: 25),
                        ),
                      ),
                    ],
                  )
                : ListView(
                    padding: const EdgeInsets.all(20),
                    controller: scrollController,
                    children: [
                      Text(
                        "We sent an sms with a verification code to ${widget.phone}",
                        style: const TextStyle(fontSize: 25),
                      ),
                      const SizedBox(height: 10),
                      const Divider(),
                      if (controller.isListeningForOtpAutoRetrieve)
                        Column(
                          children: const [
                            Center(
                                child: CircularProgressIndicator(
                                    color: primaryColor)),
                            SizedBox(height: 50),
                            Text(
                              "Listening to OTP",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(height: 15),
                            Divider(),
                            Text("Or", textAlign: TextAlign.center),
                            Divider(),
                          ],
                        ),
                      const SizedBox(height: 15),
                      const Text(
                        "Enter OTP",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 15),
                      PinInputField(
                        length: 6,
                        onFocusChange: (hasFocus) async {
                          if (hasFocus) await _scrollToBottomOnKeyboardOpen();
                        },
                        onSubmit: (enteredOtp) async {
                          final verified =
                              await controller.verifyOtp(enteredOtp);
                          if (verified) {
                            // context.read<AuthProvider>().setPhoneVerified(true);
                            // Navigator.pop(context);
                            // number verify success
                            // will call onLoginSuccess handler
                          } else {
                            // phone verification failed
                            // will call onLoginFailed or onError callbacks with the error
                          }
                        },
                      ),
                    ],
                  ),
          );
        },
      ),
    );
  }
}
