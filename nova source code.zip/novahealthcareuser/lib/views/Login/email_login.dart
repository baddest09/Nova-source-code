import 'package:animation_wrappers/animation_wrappers.dart';

import 'package:doctoworld_doctor/widgets/text_fields.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../translations/locale_keys.g.dart';

class EmailLogin extends StatelessWidget {
  EmailLogin({super.key});

  final _emailController = TextEditingController();
  final _passController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      body: FadedSlideAnimation(
        beginOffset: const Offset(0, 0.3),
        endOffset: const Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
        child: SingleChildScrollView(
          child: Stack(
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                height: size.height * 0.6,
                color: Theme.of(context).backgroundColor,
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Spacer(),
                    Expanded(
                        flex: 2, child: Image.asset('assets/doctor_logo.png')),
                    const Spacer(),
                    Expanded(
                        flex: 4, child: Image.asset('assets/hero_image.png')),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    SizedBox(height: size.height * 0.52),
                    EntryField3(
                      hint: LocaleKeys.enteremail.tr(),
                      prefixIcon: Icons.phone_iphone,
                      color: Theme.of(context).scaffoldBackgroundColor,
                      controller: _emailController,
                    ),
                    const SizedBox(height: 20.0),
                    EntryField3(
                      hint: LocaleKeys.enterpass.tr(),
                      prefixIcon: Icons.phone_iphone,
                      color: Theme.of(context).scaffoldBackgroundColor,
                      controller: _passController,
                    ),
                    const SizedBox(height: 15.0),
                    SizedBox(
                      width: 260,
                      height: 50,
                      child: ElevatedButton(
                        child: Text(LocaleKeys.login.tr(),
                            style: const TextStyle(
                                color: Colors.white, fontSize: 21)),
                        onPressed: () {
                          if (_emailController.text.isNotEmpty &&
                              _passController.text.isNotEmpty) {
                            context.read<AuthProvider>().sigin(
                                  _emailController.text.trim(),
                                  _passController.text.trim(),
                                );
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
