// ignore_for_file: must_be_immutable

import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_field/phone_number.dart';
import 'package:one_context/one_context.dart';

import '../verify_phone.dart';

class PhoneLogin extends StatelessWidget {
  PhoneLogin({super.key});

  final _phoneController = TextEditingController();
  String phone = "";

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      body: FadedSlideAnimation(
        beginOffset: const Offset(0, 0.3),
        endOffset: const Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
        child: SingleChildScrollView(
          child: Stack(
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                height: size.height * 0.6,
                color: Theme.of(context).backgroundColor,
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Spacer(),
                    Expanded(
                        flex: 2, child: Image.asset('assets/doctor_logo.png')),
                    const Spacer(),
                    Expanded(
                        flex: 4, child: Image.asset('assets/hero_image.png')),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    SizedBox(height: size.height * 0.52),
                    IntlPhoneField(
                      onChanged: (PhoneNumber number) {
                        phone = number.completeNumber;
                      },
                      initialValue: _phoneController.text,
                      controller: _phoneController,
                      initialCountryCode: 'UG',
                      // keyboardType: const TextInputType.numberWithOptions(
                      //     signed: true, decimal: true),
                      decoration: InputDecoration(
                          hintText: 'Phone number',
                          hintStyle: Theme.of(context)
                              .textTheme
                              .bodyText1!
                              .copyWith(color: Colors.grey, fontSize: 15),
                          filled: true,
                          fillColor: scaffoldBackgroundColor,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide.none,
                          )),
                    ),
                    const SizedBox(height: 15.0),
                    SizedBox(
                      width: 260,
                      height: 50,
                      child: ElevatedButton(
                          child: const Text("Proceed",
                              style:
                                  TextStyle(color: Colors.white, fontSize: 21)),
                          onPressed: () async {
                            if (phone.startsWith("+") == true) {
                              OneContext().push(MaterialPageRoute(
                                  builder: (_) => VerifyPhoneNumberScreen(
                                      phone: phone, isLogin: true)));
                            }
                          }),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
