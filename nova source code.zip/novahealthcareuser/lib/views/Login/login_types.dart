import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/providers/auth_provider.dart';
import 'package:doctoworld_doctor/router/app_router.dart';
import 'package:doctoworld_doctor/translations/locale_keys.g.dart';
import 'package:doctoworld_doctor/utils/colors.dart';
import 'package:doctoworld_doctor/utils/navigates.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:social_login_buttons/social_login_buttons.dart';

class LoginTypes extends StatelessWidget {
  const LoginTypes({super.key});

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      body: FadedSlideAnimation(
        beginOffset: const Offset(0, 0.3),
        endOffset: const Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
        child: SingleChildScrollView(
          child: Stack(
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                height: size.height * 0.6,
                color: Theme.of(context).backgroundColor,
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Spacer(),
                    Expanded(
                        flex: 2, child: Image.asset('assets/doctor_logo.png')),
                    const Spacer(),
                    Expanded(
                        flex: 4, child: Image.asset('assets/hero_image.png')),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    SizedBox(height: size.height * 0.52),
                    SocialLoginButton(
                      imageWidth: 30,
                      imageURL:
                          "https://cdn-icons-png.flaticon.com/512/893/893247.png",
                      backgroundColor: Colors.red,
                      text: 'Email Sign In',
                      buttonType: SocialLoginButtonType.generalLogin,
                      onPressed: () {
                        customPush(AppRoutes.EMAILLOGIN);
                      },
                    ),
                    const SizedBox(height: 15.0),
                    SocialLoginButton(
                      imageWidth: 30,
                      imageURL:
                          "https://cdn-icons-png.flaticon.com/512/684/684911.png",
                      backgroundColor: primaryColor,
                      text: 'Phone Sign In',
                      buttonType: SocialLoginButtonType.generalLogin,
                      onPressed: () {
                        customPush(AppRoutes.PHONELOGIN);
                      },
                    ),
                    const SizedBox(height: 15.0),
                    SocialLoginButton(
                      buttonType: SocialLoginButtonType.google,
                      onPressed: () {
                        context.read<AuthProvider>().signInWithGoogle();
                      },
                    ),
                    const SizedBox(height: 15.0),
                    const Text(
                      "or",
                      style: TextStyle(color: Colors.red, fontSize: 18),
                    ),
                    const SizedBox(height: 10),
                    InkWell(
                      child: Text(
                        LocaleKeys.signup.tr(),
                        style: TextStyle(
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                      onTap: () {
                        customPush(AppRoutes.REGISTERTYPE);
                      },
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
