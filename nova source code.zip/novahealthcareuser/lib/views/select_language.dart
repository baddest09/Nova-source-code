import 'package:animation_wrappers/animations/faded_slide_animation.dart';
import 'package:doctoworld_doctor/providers/select_language_provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../translations/locale_keys.g.dart';
import '../utils/app_constants.dart';

class SelectLanguage extends StatelessWidget {
  const SelectLanguage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        centerTitle: true,
        title: Text(
          LocaleKeys.changeLanguage.tr(),
          style: Theme.of(context)
              .textTheme
              .bodyText2!
              .copyWith(fontSize: 17, fontWeight: FontWeight.w700),
        ),
        toolbarTextStyle: Theme.of(context).textTheme.bodyText2,
        titleTextStyle: Theme.of(context).textTheme.headline6,
      ),
      body: FadedSlideAnimation(
        beginOffset: const Offset(0, 0.3),
        endOffset: const Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
        child: Stack(
          children: [
            ListView(
              children: [
                ListView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: AppConfig.languagesSupported.length,
                  shrinkWrap: true,
                  itemBuilder: (context, index) => RadioListTile(
                    value: AppConfig.languagesSupported.keys.elementAt(index),
                    groupValue:
                        context.watch<SelectLanguageProvider>().currentLocale,
                    title: Text(
                      AppConfig
                          .languagesSupported[AppConfig.languagesSupported.keys
                              .elementAt(index)]!
                          .name,
                      style: Theme.of(context).textTheme.bodyText2!.copyWith(
                            fontSize: 15,
                          ),
                    ),
                    onChanged: (langCode) =>
                        context.read<SelectLanguageProvider>().changeLocal(
                              context,
                              AppConfig
                                  .languagesSupported[AppConfig
                                      .languagesSupported.keys
                                      .elementAt(index)]!
                                  .values,
                            ),
                  ),
                ),
              ],
            ),
            Align(
              alignment: Alignment.bottomRight,
              child: Container(
                padding: const EdgeInsets.all(1),
                width: 160,
                height: 50,
                child: ElevatedButton(
                  child: Text(LocaleKeys.continuee.tr(),
                      style:
                          const TextStyle(color: Colors.white, fontSize: 21)),
                  onPressed: () {
                    context.read<SelectLanguageProvider>().changeLocal(context,
                        context.read<SelectLanguageProvider>().currentLocale,
                        isContinue: true);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
