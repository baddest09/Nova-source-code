import 'package:flutter/material.dart';
import '../utils/colors.dart';

class TitleRow extends StatelessWidget {
  final String? title;
  final Function? onTap;

  const TitleRow(this.title, this.onTap, {super.key});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsetsDirectional.only(start: 20.0),
      title: Text(
        title!,
        style: Theme.of(context)
            .textTheme
            .bodyText1!
            .copyWith(color: lightGreyColor, fontSize: 14.5),
      ),
      trailing: onTap != null
          ? TextButton(
              onPressed: onTap as void Function()?,
              child: Text(
                "View all",
                style: Theme.of(context).textTheme.bodyText1!.copyWith(
                    color: Theme.of(context).primaryColor, fontSize: 14.5),
              ),
            )
          : const SizedBox.shrink(),
    );
  }
}
