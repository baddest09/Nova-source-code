import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/colors.dart';

class EntryField3 extends StatefulWidget {
  final String? hint;
  final IconData? prefixIcon;
  final Color? color;
  final Color? color2;
  final int? maxLength;
  final TextEditingController? controller;
  final String? initialValue;
  final bool? readOnly;
  final TextAlign? textAlign;
  final IconData? suffixIcon;
  final TextInputType? textInputType;
  final String? label;
  final int? maxLines;
  final bool? isDense;
  final void Function()? onTap;
  final void Function(String)? onChanged;
  final List<TextInputFormatter>? inputFormatters;
  const EntryField3(
      {super.key,
      this.hint,
      this.prefixIcon,
      this.color,
      this.color2,
      this.maxLength,
      this.controller,
      this.initialValue,
      this.readOnly,
      this.textAlign,
      this.suffixIcon,
      this.textInputType,
      this.label,
      this.maxLines,
      this.isDense,
      this.onTap,
      this.onChanged,
      this.inputFormatters});

  @override
  State<EntryField3> createState() => _EntryField3State();
}

class _EntryField3State extends State<EntryField3> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        widget.label != null
            ? Text('\n${widget.label!}\n',
                style: Theme.of(context)
                    .textTheme
                    .subtitle2!
                    .copyWith(color: const Color(0xff808080)))
            : const SizedBox.shrink(),
        TextFormField(
          inputFormatters: widget.inputFormatters,
          onChanged: widget.onChanged,
          maxLength: widget.maxLength,
          onTap: widget.onTap,
          controller: widget.controller,
          initialValue: widget.initialValue,
          readOnly: widget.readOnly ?? false,
          maxLines: widget.maxLines ?? 1,
          textAlign: widget.textAlign ?? TextAlign.left,
          keyboardType: widget.textInputType,
          decoration: InputDecoration(
              isDense: widget.isDense ?? widget.isDense,
              prefixIcon: widget.prefixIcon != null
                  ? Icon(
                      widget.prefixIcon,
                      color: Theme.of(context).primaryColor,
                      size: 18.5,
                    )
                  : null,
              suffixIcon: Icon(widget.suffixIcon),
              hintText: widget.hint,
              hintStyle: Theme.of(context).textTheme.bodyText1!.copyWith(
                  color: widget.color2 ?? textFieldColor, fontSize: 15),
              filled: true,
              fillColor: widget.color ?? Theme.of(context).primaryColorLight,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              )),
        ),
      ],
    );
  }
}
