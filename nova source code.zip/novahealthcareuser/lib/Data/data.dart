final banner = [
  'assets/banners/Item 1.png',
  'assets/banners/Item 1 copy 9.png',
];
final List<String> categories = [
  'assets/CategoryImages/Otc.png',
  'assets/CategoryImages/Diabetes.png',
  'assets/CategoryImages/Baby.png',
  'assets/CategoryImages/Per.png',
  'assets/CategoryImages/Well.png',
];
final List<String> stores = [
  "assets/SellerImages/4.png",
  "assets/SellerImages/1a.png",
  "assets/SellerImages/2.png",
  "assets/SellerImages/3.png",
  "assets/SellerImages/4.png",
  "assets/SellerImages/1.png",
];

final doctorBanners = [
  'assets/banners/Item 1.png',
  'assets/banners/Item 1 copy 9.png',
];
final List<String> doctorCategories = [
  'assets/DoctorCategory/Doctors.png',
  'assets/DoctorCategory/Dentists.png',
  'assets/DoctorCategory/Ayurvadic.png',
  'assets/DoctorCategory/Therapist.png',
  'assets/DoctorCategory/Doctors.png',
  'assets/DoctorCategory/Dentists.png',
  'assets/DoctorCategory/Ayurvadic.png',
  'assets/DoctorCategory/Therapist.png',
];
final List<String> specialities = [
  'Addiction psychiatrist',
  'Adolescent medicine specialist',
  'Allergist (immunologist)',
  'Adolescent medicine specialist',
  'Allergist (immunologist)',
];
