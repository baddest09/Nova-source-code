import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:doctoworld_doctor/providers/appointment_provider.dart';
import 'package:doctoworld_doctor/providers/auth_provider.dart';
import 'package:doctoworld_doctor/providers/doctors_provider.dart';
import 'package:doctoworld_doctor/providers/profile_provider.dart';
import 'package:doctoworld_doctor/providers/select_language_provider.dart';
import 'package:doctoworld_doctor/router/app_router.dart';
import 'package:doctoworld_doctor/services/notificationapis.dart';
import 'package:doctoworld_doctor/translations/codegen_loader.g.dart';
import 'package:doctoworld_doctor/utils/app_constants.dart';
import 'package:doctoworld_doctor/utils/colors.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:one_context/one_context.dart';
import 'package:provider/provider.dart';

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();

  debugPrint('Handling a background message ${message.messageId}');
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final savedThemeMode = await AdaptiveTheme.getThemeMode();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  // removeAll();
  await Firebase.initializeApp();
  await requestPermission();
  await loadFCM();
  await listenFCM();
  await EasyLocalization.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(statusBarColor: Colors.transparent));
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => SelectLanguageProvider()),
        ChangeNotifierProvider(create: (_) => ProfileProvider()),
        ChangeNotifierProvider(create: (_) => DoctorsProvider()),
        ChangeNotifierProvider(create: (_) => AppointmentProvider()),
      ],
      child: EasyLocalization(
        saveLocale: true,
        path: 'assets/translations',
        supportedLocales: const [
          Locale('en'),
          Locale('ar'),
          Locale('pt'),
          Locale('fr'),
          Locale('id'),
          Locale('es'),
          Locale('it'),
          Locale('tr'),
          Locale('sw'),
          Locale('de'),
          Locale('ro'),
        ],
        fallbackLocale: const Locale('en'),
        assetLoader: const CodegenLoader(),
        child: MyApp(savedThemeMode: savedThemeMode),
      ),
    ),
  );
}

class MyApp extends StatelessWidget {
  final AdaptiveThemeMode? savedThemeMode;

  const MyApp({super.key, required this.savedThemeMode});

  @override
  Widget build(BuildContext context) {
    return AdaptiveTheme(
      initial: savedThemeMode ?? AdaptiveThemeMode.light,
      light: ThemeData(
          brightness: Brightness.light,
          primaryColor: kMainColor,
          backgroundColor: const Color(0xffF4F7F8),
          scaffoldBackgroundColor: Colors.white,
          dividerColor: const Color(0xffF4F7F8),
          textTheme: const TextTheme(
            caption: TextStyle(),
            // button: TextStyle(color: Colors.white),
            bodyText1: TextStyle(),
            subtitle1: TextStyle(),
            subtitle2: TextStyle(),
            bodyText2: TextStyle(),
            headline6: TextStyle(),
          ),
          appBarTheme: const AppBarTheme(
              color: Colors.transparent,
              elevation: 0,
              iconTheme: IconThemeData(color: Colors.black))),
      dark: ThemeData(
        brightness: Brightness.dark,
        primaryColor: kMainColor,
        scaffoldBackgroundColor: const Color(0xFF121212),
        appBarTheme: const AppBarTheme(
            color: Colors.transparent,
            elevation: 0,
            iconTheme: IconThemeData(color: Colors.white)),
        // textTheme: const TextTheme(
        // caption: TextStyle(),
        // button: TextStyle(color: Colors.white),
        // bodyText1: TextStyle(),

        // subtitle2: TextStyle(),
        // bodyText2: TextStyle(),
        // headline6: TextStyle(),
        // ),
      ),
      builder: (theme, darkTheme) => MaterialApp(
        supportedLocales: context.supportedLocales,
        localizationsDelegates: context.localizationDelegates,
        locale: context.locale,
        builder: OneContext().builder,
        initialRoute: AppRoutes.SPLASH,
        title: AppConstants.APP_NAME,
        navigatorKey: OneContext().key,
        routes: AppRoutes.getAppRoutes(),
        debugShowCheckedModeBanner: false,
        theme: theme,
        darkTheme: darkTheme,
      ),
    );
  }
}
