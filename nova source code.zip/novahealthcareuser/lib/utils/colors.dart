import 'package:flutter/material.dart';

const Color kMainColor = Color(0xff0fc1a7);
const Color kLightHintColor = Color(0xffa7a7a7);
const Color kTextFieldLabelColor = Color(0xff838383);
const Color kTransparentColor = Colors.transparent;
const Color starColor = Colors.yellow;
const Color dayTimeTextBackground = Color(0xfff4f7f8);
const Color dayTimeTextColor = Color(0xffababab);
const scaffoldBackgroundColor = Colors.white;
const backgroundColor = Color(0xffC4EBF2);
const primaryColor = Color(0xff56C2A8);
const secondaryBackgroundColor = Color(0xffF4F7F8);
const facebookButtonColor = Color(0xff3b45c1);
const textColor = Colors.black;
const transparentColor = Colors.transparent;
const disabledColor = Color(0xff7B7B7B);

const textFieldColor = Color(0xff7c7c7c);
const lightGreyColor = Color(0xffacacac);
const black2 = Color(0xff4d4d4d);
