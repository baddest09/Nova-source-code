// import 'package:easy_localization/easy_localization.dart';
// import 'package:flutter/material.dart';
// import 'package:garage4u/utils/shared_preference.dart';
// import 'package:one_context/one_context.dart';
// import 'package:url_launcher/url_launcher.dart';

// import '../translations/locale_keys.g.dart';
// import '../widgets/buttons.dart';
// import 'app_constants.dart';
// import 'colors.dart';

// Future getUserid() async {
//   return await getStringValue("userid");
// }

// Future getProfileStatus() async {
//   return await getBoolValue(AppConstants.PROFILECREATED);
// }

// Future<void> makePhoneCall(String phoneNumber) async {
//   final Uri launchUri = Uri(
//     scheme: 'tel',
//     path: phoneNumber,
//   );
//   await launchUrl(launchUri);
// }

// Future<void> contactUsCall() async {
//   final Uri launchUri = Uri(
//     scheme: 'tel',
//     path: "0585408910",
//   );
//   await launchUrl(launchUri);
// }

// openwhatsapp() async {
//   var whatsapp = "+971585408910";
//   launchUrl(Uri.parse('https://wa.me/$whatsapp?text=Hi'),
//       mode: LaunchMode.externalApplication);
// }

// void openNumberDialog(String url, String phone, String name) {
//   OneContext().push(
//     MaterialPageRoute<void>(
//       builder: (BuildContext context) {
//         return Scaffold(
//           appBar: AppBar(
//             foregroundColor: Colors.white,
//             iconTheme: const IconThemeData(color: Colors.white),
//           ),
//           body: Padding(
//             padding: const EdgeInsets.all(24),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   children: [
//                     Container(
//                       width: 80,
//                       height: 80,
//                       decoration: BoxDecoration(
//                         color: greyColor,
//                         borderRadius: BorderRadius.circular(20),
//                         border: Border.all(
//                           color: secondaryColor,
//                           width: 2,
//                         ),
//                       ),
//                       child: ClipRRect(
//                         borderRadius: BorderRadius.circular(20),
//                         child: Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: Image.network(
//                             url,
//                             fit: BoxFit.cover,
//                           ),
//                         ),
//                       ),
//                     ),
//                     const SizedBox(width: 10),
//                     Text(
//                       name,
//                       maxLines: 2,
//                       overflow: TextOverflow.ellipsis,
//                       style: const TextStyle(
//                         color: primaryColor,
//                         fontSize: 20,
//                         fontWeight: FontWeight.w900,
//                       ),
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 20),
//                 CustomButton(
//                   width: double.maxFinite,
//                   color: secondaryColor,
//                   onPressed: () => makePhoneCall(phone),
//                   text: "${LocaleKeys.Call.tr()}  $phone",
//                 )
//               ],
//             ),
//           ),
//         );
//       },
//       fullscreenDialog: true,
//     ),
//   );
// }

import 'package:easy_localization/easy_localization.dart';

String convertDateTimeDisplay(String date) {
  final DateFormat displayFormater = DateFormat('yyyy-MM-dd HH:mm:ss.SSS');
  final DateFormat serverFormater = DateFormat('dd-MM-yyyy');
  final DateTime displayDate = displayFormater.parse(date);
  final String formatted = serverFormater.format(displayDate);
  return formatted;
}
