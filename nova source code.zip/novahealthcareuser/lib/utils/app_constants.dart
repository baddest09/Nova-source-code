// ignore_for_file: constant_identifier_names

class AppConstants {
  static const String APP_NAME = 'DoctoWorld Doctor';

  // Images
  static const String LOGO_IMAGE = "images/logo.png";

  // shared preferences

  static const USERID = "userid";
  static const ISLANGUAGESELECTED = "islanguageselected";

  // Lnaguage
  static const LANGUAGE = "language";

  static const smsKey =
      "AAAA_ghHMc0:APA91bHbjcQKzt8hSdnBd9TBnmaJ07ylb0aFIMd1Zm2nh38tshp9qESehmsCKp1jNkahC4gw1LWt3JWoa4oo7VhbMkb__f6_7MZPFJWE5gvmdzSGiaFFP7i2vqyq6MzJ57aKjFksyxmN";
}

class AppConfig {
  static final Map<String, AppLanguage> languagesSupported = {
    "en": AppLanguage("English", "en"),
    "ar": AppLanguage("عربى", "ar"),
    "pt": AppLanguage("Portugal", "pt"),
    "fr": AppLanguage("Français", "fr"),
    "id": AppLanguage("Bahasa Indonesia", "id"),
    "es": AppLanguage("Español", "es"),
    "it": AppLanguage("italiano", "it"),
    "tr": AppLanguage("Türk", "tr"),
    "sw": AppLanguage("Kiswahili", "sw"),
    "de": AppLanguage("Deutsch", "de"),
    "ro": AppLanguage("Română", "ro"),
  };
}

class AppLanguage {
  final String name;
  final String values;
  AppLanguage(this.name, this.values);
}

class AgoraConfig {
  static const String token = '';
  static const String appId = '3122ef90844d45fb8f36313d8f5e6f2a';
  static const String appCertificate = '92ed6e172ed94f32be80342d679fde95';
  static const String tokenBaseUrl =
      'https://lets-chat-mateendev3.herokuapp.com';
}
