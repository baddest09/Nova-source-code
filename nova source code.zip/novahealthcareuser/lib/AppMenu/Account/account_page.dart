import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:day_night_switcher/day_night_switcher.dart';
import 'package:doctoworld_doctor/providers/auth_provider.dart';
import 'package:doctoworld_doctor/router/app_router.dart';
import 'package:doctoworld_doctor/translations/locale_keys.g.dart';
import 'package:doctoworld_doctor/utils/navigates.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class MenuTile {
  String? title;
  String? subtitle;
  IconData iconData;
  Function onTap;
  MenuTile(this.title, this.subtitle, this.iconData, this.onTap);
}

class AccountPage extends StatefulWidget {
  const AccountPage({super.key});

  @override
  State<AccountPage> createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> {
  @override
  Widget build(BuildContext context) {
    List<MenuTile> menu = [
      MenuTile("Profile", "Setup profile", Icons.store, () {
        customPush(AppRoutes.PROFILE);
      }),
      MenuTile("Language", LocaleKeys.changeLanguage.tr(), Icons.language, () {
        customPush(AppRoutes.SELECTLANGUAGE);
      }),
      MenuTile(LocaleKeys.contactUs.tr(), LocaleKeys.contactUs.tr(), Icons.mail,
          () {
        customPush(AppRoutes.contactUsPage);
      }),
      // MenuTile(LocaleKeys.tnC, LocaleKeys.policies, Icons.assignment, () {
      //   Navigator.pushNamed(context, PageRoutes.tncPage);
      // }),
      // MenuTile(LocaleKeys.faqs, LocaleKeys.quickAnswers, Icons.announcement, () {
      //   Navigator.pushNamed(context, PageRoutes.faqPage);
      // }),
      MenuTile("Logout", "See you", Icons.exit_to_app, () {
        context.read<AuthProvider>().signout();
      }),
    ];
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(
          "Account",
          style: Theme.of(context)
              .textTheme
              .bodyText2!
              .copyWith(fontSize: 17, fontWeight: FontWeight.w700),
        ),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: DayNightSwitcherIcon(
              isDarkModeEnabled:
                  AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light
                      ? false
                      : true,
              onStateChanged: (isDarkModeEnabled) {
                if (AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light) {
                  AdaptiveTheme.of(context).setDark();
                } else {
                  AdaptiveTheme.of(context).setLight();
                }
                setState(() {});
              },
            ),
          ),
        ],
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        children: [
          Container(
            color: Theme.of(context).primaryColorLight,
            child: GridView.builder(
                itemCount: menu.length,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                padding: const EdgeInsets.all(8.0),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    childAspectRatio: 1.6,
                    crossAxisCount: 2,
                    mainAxisExtent: 102),
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: menu[index].onTap as void Function()?,
                    child: Container(
                      margin: const EdgeInsets.symmetric(
                          vertical: 6, horizontal: 6),
                      padding: const EdgeInsets.symmetric(
                          vertical: 12, horizontal: 12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        color: Theme.of(context).scaffoldBackgroundColor,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          FadedScaleAnimation(
                            child: Text(
                              menu[index].title!,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyText1!
                                  .copyWith(fontWeight: FontWeight.bold),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const SizedBox(
                            height: 8,
                          ),
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  menu[index].subtitle!,
                                  style: Theme.of(context)
                                      .textTheme
                                      .subtitle2!
                                      .copyWith(
                                          fontSize: 12, color: Colors.grey),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              Icon(
                                menu[index].iconData,
                                size: 32,
                                color: Theme.of(context).primaryColorLight,
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                }),
          ),
        ],
      ),
    );
  }
}
