import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:doctoworld_doctor/providers/profile_provider.dart';
import 'package:doctoworld_doctor/translations/locale_keys.g.dart';
import 'package:doctoworld_doctor/views/location.dart';
import 'package:doctoworld_doctor/widgets/loading.dart';
import 'package:doctoworld_doctor/widgets/text_fields.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_field/phone_number.dart';
import 'package:provider/provider.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  // final _nameController = TextEditingController();
  // final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  // int _feesController = 10;
  // int _expController = 10;
  // final _addressController = TextEditingController();
  // PhoneNumber? number;

  @override
  void initState() {
    super.initState();

    // setState(() {
    //   _nameController.text = context.read<ProfileProvider>().name;
    //   _emailController.text = context.read<ProfileProvider>().email;
    _phoneController.text = context.read<ProfileProvider>().phone;
    // number = PhoneNumber(
    //     countryCode: '+256',
    //     countryISOCode: 'UG',
    //     number: context.read<ProfileProvider>().phone);
    //   _feesController = int.tryParse(context.read<ProfileProvider>().fees) ?? 0;
    //   _expController = int.tryParse(context.read<ProfileProvider>().exp) ?? 0;
    //   _addressController.text = context.read<ProfileProvider>().address;
    // });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.chevron_left)),
        centerTitle: true,
        title: Text(
          LocaleKeys.myProfile,
          style: Theme.of(context)
              .textTheme
              .bodyText2!
              .copyWith(fontSize: 17, fontWeight: FontWeight.w700),
        ),
        toolbarTextStyle: Theme.of(context).textTheme.bodyText2,
        titleTextStyle: Theme.of(context).textTheme.headline6,
      ),
      body: context.watch<ProfileProvider>().isLoading
          ? const Loading()
          : FadedSlideAnimation(
              beginOffset: const Offset(0, 0.3),
              endOffset: const Offset(0, 0),
              slideCurve: Curves.linearToEaseOut,
              child: ListView(
                physics: const BouncingScrollPhysics(),
                children: [
                  Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        FadedScaleAnimation(
                          child: context.read<ProfileProvider>().logo != null
                              ? Image.file(
                                  width:
                                      MediaQuery.of(context).size.width / 2.5,
                                  context.read<ProfileProvider>().logo!)
                              : CachedNetworkImage(
                                  width:
                                      MediaQuery.of(context).size.width / 2.5,
                                  imageUrl:
                                      context.read<ProfileProvider>().imageUrl,
                                  placeholder: (context, url) =>
                                      const Loading(),
                                  errorWidget: (context, url, error) =>
                                      Image.asset("assets/doctors/doc1.png"),
                                ),
                        ),
                        const SizedBox(width: 20),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            GestureDetector(
                              onTap: () {
                                context.read<ProfileProvider>().pickLogo();
                              },
                              child: CircleAvatar(
                                  radius: 14,
                                  backgroundColor:
                                      Theme.of(context).primaryColor,
                                  child: Icon(
                                    Icons.camera_alt,
                                    color: Theme.of(context)
                                        .scaffoldBackgroundColor,
                                    size: 16,
                                  )),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              "Change Profile Picture",
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyText1!
                                  .copyWith(
                                      color: Theme.of(context).primaryColor,
                                      fontWeight: FontWeight.w600),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                  const Divider(
                    thickness: 8,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        EntryField3(
                          key: Key(
                              context.watch<ProfileProvider>().name.toString()),
                          prefixIcon: Icons.account_circle,
                          initialValue: context.watch<ProfileProvider>().name,
                          onChanged: (value) {
                            context.read<ProfileProvider>().name = value;
                          },
                        ),
                        const SizedBox(height: 20),
                        IntlPhoneField(
                          // key: Key(context
                          //     .watch<ProfileProvider>()
                          //     .phone
                          //     .toString()),
                          onChanged: (PhoneNumber number) {
                            context.read<ProfileProvider>().phone =
                                number.completeNumber;
                          },
                          initialValue: _phoneController.text,
                          controller: _phoneController,
                          initialCountryCode: 'UG',
                          // keyboardType: const TextInputType.numberWithOptions(
                          //     signed: true, decimal: true),
                          decoration: InputDecoration(
                              hintText: 'Phone number',
                              hintStyle: Theme.of(context)
                                  .textTheme
                                  .bodyText1!
                                  .copyWith(color: Colors.grey, fontSize: 15),
                              filled: true,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide.none,
                              )),
                        ),
                        // EntryField3(
                        //   key: Key(context
                        //       .watch<ProfileProvider>()
                        //       .phone
                        //       .toString()),
                        //   initialValue: context.watch<ProfileProvider>().phone,
                        //   prefixIcon: Icons.phone_iphone,
                        //   onChanged: (value) {
                        //     context.read<ProfileProvider>().phone = value;
                        //   },
                        // ),
                        const SizedBox(height: 20),
                        EntryField3(
                          initialValue: context.watch<ProfileProvider>().email,
                          readOnly: true,
                          prefixIcon: Icons.mail,
                        ),
                        const SizedBox(height: 20),
                        const GetLocationWidget()
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 16),
                    child: SizedBox(
                      height: 50,
                      child: ElevatedButton(
                        child: Text(LocaleKeys.update.tr(),
                            style: const TextStyle(
                                color: Colors.white, fontSize: 21)),
                        onPressed: () {
                          context.read<ProfileProvider>().updateProfile(
                                context.read<ProfileProvider>().name,
                                context.read<ProfileProvider>().email,
                                context.read<ProfileProvider>().phone,
                              );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
