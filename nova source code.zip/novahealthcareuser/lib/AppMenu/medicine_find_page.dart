// ignore_for_file: library_private_types_in_public_api

import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/providers/profile_provider.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../Data/data.dart';
import '../utils/colors.dart';
import '../widgets/title_row.dart';

class MedicinePage extends StatelessWidget {
  const MedicinePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const FindMedicine();
  }
}

class FindMedicine extends StatefulWidget {
  const FindMedicine({super.key});

  @override
  _FindMedicineState createState() => _FindMedicineState();
}

class _FindMedicineState extends State<FindMedicine> {
  @override
  Widget build(BuildContext context) {
    // String? value = 'Wallington';
    return Builder(builder: (BuildContext context) {
      return Scaffold(
        appBar: AppBar(
          title: Row(
            children: [
              const Spacer(),
              const Text("Nova Health Care",
                  style: TextStyle(color: primaryColor)),
              const SizedBox(width: 5),
              Image.asset("assets/doctor_logo.png", height: 25),
              const Spacer(),
            ],
          ),
        ),
        body: Stack(
          children: [
            ListView(
              physics: const BouncingScrollPhysics(),
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(
                      left: 20.0, top: 20, right: 20, bottom: 14),
                  child: Text(
                    "Hello" ', ${context.read<ProfileProvider>().name},',
                    style: Theme.of(context).textTheme.subtitle2!.copyWith(
                        color: lightGreyColor, fontWeight: FontWeight.w500),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: FadedScaleAnimation(
                    child: Text(
                      "Find your medicines",
                      style: Theme.of(context)
                          .textTheme
                          .headline5!
                          .copyWith(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 25,
                ),
                FadedScaleAnimation(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 8.0, horizontal: 16),
                    child: TextFormField(
                      onTap: () {
                        //Navigator.pushNamed(context, PageRoutes.searchDoctors);
                      },
                      decoration: InputDecoration(
                          hintText: "Search by medicines",
                          hintStyle: Theme.of(context)
                              .textTheme
                              .bodyText1!
                              .copyWith(color: textFieldColor, fontSize: 15),
                          prefixIcon: const Icon(
                            Icons.search,
                            size: 20,
                          ),
                          filled: true,
                          fillColor: Theme.of(context).backgroundColor,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide.none)),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                TitleRow("Shop by category", () {}),
                SizedBox(
                  height: 124,
                  child: ListView.builder(
                      shrinkWrap: true,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      itemCount: categories.length,
                      itemBuilder: (context, index) {
                        return InkWell(
                          onTap: () {},
                          child: Padding(
                            padding: const EdgeInsetsDirectional.only(end: 8),
                            child: FadedScaleAnimation(
                              child: Image.asset(
                                categories[index],
                                width: 96,
                                fit: BoxFit.fill,
                              ),
                            ),
                          ),
                        );
                      }),
                ),
                TitleRow("Offers", () {}),
                SizedBox(
                  height: 108,
                  child: ListView.builder(
                      shrinkWrap: true,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      itemCount: banner.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsetsDirectional.only(end: 20),
                          child: GestureDetector(
                              onTap: () {},
                              child: FadedScaleAnimation(
                                child: Image.asset(banner[index],
                                    fit: BoxFit.fill),
                              )),
                        );
                      }),
                ),
                const TitleRow("Seller near you", null),
                SizedBox(
                  height: 156,
                  child: GridView.builder(
                    itemCount: stores.length,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 20,
                      childAspectRatio: 0.38,
                    ),
                    shrinkWrap: true,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    physics: const BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) =>
                        quickGrid(context, stores[index]),
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    });
  }

  Widget quickGrid(BuildContext context, String image) {
    return GestureDetector(
      onTap: () {},
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          FadedScaleAnimation(
            child: Image(
              image: AssetImage(image),
              height: 54,
            ),
          ),
          const SizedBox(width: 13.3),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('Well Life Store',
                  style: Theme.of(context)
                      .textTheme
                      .subtitle1!
                      .copyWith(fontSize: 15, color: black2)),
              const SizedBox(height: 8.0),
              Row(
                children: [
                  const Icon(
                    Icons.location_on,
                    color: Color(0xff999999),
                    size: 12,
                  ),
                  Text(' ' 'Willington Bridge',
                      style: Theme.of(context).textTheme.caption!.copyWith(
                          color: Theme.of(context).disabledColor,
                          fontSize: 10.0)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
