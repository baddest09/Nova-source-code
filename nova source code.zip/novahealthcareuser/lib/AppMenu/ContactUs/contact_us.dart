// ignore_for_file: library_private_types_in_public_api

import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/translations/locale_keys.g.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import '../../utils/colors.dart';

class ContactUsPage extends StatefulWidget {
  const ContactUsPage({super.key});

  @override
  _ContactUsPageState createState() => _ContactUsPageState();
}

class _ContactUsPageState extends State<ContactUsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: dayTimeTextBackground,
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.chevron_left)),
        title: Text(LocaleKeys.contactUs.tr()),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          ListView(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            children: [
              const SizedBox(
                height: 12,
              ),
              Text(
                '${LocaleKeys.howMayWe.tr()}\n${LocaleKeys.helpYou.tr()}',
                style: Theme.of(context)
                    .textTheme
                    .headline5!
                    .copyWith(fontWeight: FontWeight.w600, fontSize: 28),
              ),
              const SizedBox(
                height: 18,
              ),
              Text(
                LocaleKeys.letUsKnowYourQueriesFeedbacks.tr(),
                style:
                    Theme.of(context).textTheme.caption!.copyWith(fontSize: 15),
              ),
              const SizedBox(
                height: 36,
              ),
              ListTile(
                tileColor: Theme.of(context).scaffoldBackgroundColor,
                leading: Icon(
                  Icons.call,
                  color: Theme.of(context).primaryColor,
                  size: 30,
                ),
                title: Text(
                  LocaleKeys.contactUs.tr(),
                  style: Theme.of(context).textTheme.caption,
                ),
                subtitle: Text(
                  '+256740040404',
                  style: Theme.of(context).textTheme.bodyText1,
                ),
              ),
              const SizedBox(
                height: 12,
              ),
              ListTile(
                tileColor: Theme.of(context).scaffoldBackgroundColor,
                leading: Icon(
                  Icons.email,
                  color: Theme.of(context).primaryColor,
                  size: 30,
                ),
                title: Text(
                  LocaleKeys.emailUs.tr(),
                  style: Theme.of(context).textTheme.caption,
                ),
                subtitle: Text(
                  'sales@mydigipharmacy.com',
                  style: Theme.of(context).textTheme.bodyText1,
                ),
              ),
              // const SizedBox(
              //   height: 40,
              // ),
              // CustomButton(
              //   text: 'Submit',
              //   onTap: () {
              //     Navigator.pop(context);
              //   },
              // ),
              // const SizedBox(
              //   height: 20,
              // ),
            ],
          ),
          PositionedDirectional(
            bottom: 0,
            start: 0,
            end: 0,
            child: FadedScaleAnimation(
              child: Image.asset('assets/contact us.png'),
            ),
          ),
        ],
      ),
    );
  }
}
