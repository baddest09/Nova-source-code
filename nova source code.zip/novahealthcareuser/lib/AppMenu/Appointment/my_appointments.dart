import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/providers/appointment_provider.dart';
import 'package:doctoworld_doctor/providers/doctors_provider.dart';
import 'package:doctoworld_doctor/router/app_router.dart';
import 'package:doctoworld_doctor/utils/navigates.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:provider/provider.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';

import '../../widgets/loading.dart';

class Appointment {
  String? heading;
  List<AppointmentTile> appts;

  Appointment(this.heading, this.appts);
}

class AppointmentTile {
  String image;
  String name;
  String? disease;
  String dateTime;

  AppointmentTile(this.image, this.name, this.disease, this.dateTime);
}

class MyAppointmentsPage extends StatefulWidget {
  const MyAppointmentsPage({super.key});

  @override
  State<MyAppointmentsPage> createState() => _MyAppointmentsPageState();
}

class _MyAppointmentsPageState extends State<MyAppointmentsPage> {
  @override
  void initState() {
    super.initState();

    Future.microtask(() =>
        Provider.of<AppointmentProvider>(context, listen: false)
            .geappointments());

    Future.microtask(() =>
        Provider.of<DoctorsProvider>(context, listen: false).getDoctors());
  }

  review(String userid, String doctorid, String appointId, String username,
      String purpose) {
    double ratings = 0.0;
    final controller = TextEditingController();
    QuickAlert.show(
      context: context,
      type: QuickAlertType.info,
      barrierDismissible: true,
      confirmBtnText: 'Submit',
      widget: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RatingBar.builder(
              initialRating: ratings,
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: false,
              itemCount: 5,
              itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
              itemBuilder: (context, _) => const Icon(
                Icons.star,
                color: Colors.amber,
              ),
              onRatingUpdate: (rating) {
                ratings = rating;
              },
            ),
            TextFormField(
              controller: controller,
              decoration: const InputDecoration(
                alignLabelWithHint: true,
                hintText: 'Review',
                prefixIcon: Icon(
                  Icons.star,
                ),
              ),
              textInputAction: TextInputAction.next,
              keyboardType: TextInputType.text,
            ),
          ],
        ),
      ),
      onConfirmBtnTap: () {
        Navigator.of(context, rootNavigator: true).pop();
        context.read<AppointmentProvider>().saveReview(ratings, userid,
            doctorid, controller.text.trim(), appointId, username, purpose);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: FadedScaleAnimation(
            child: Text(
              "My appointments",
              style: Theme.of(context)
                  .textTheme
                  .bodyText2!
                  .copyWith(fontSize: 17, fontWeight: FontWeight.w700),
            ),
          ),
          centerTitle: true,
          actions: [
            IconButton(
              icon: const Icon(
                Icons.history,
                size: 22,
              ),
              color: Theme.of(context).primaryColor,
              onPressed: () {},
            )
          ],
        ),
        body: Consumer<AppointmentProvider>(builder: (context, provider, __) {
          return Column(
            children: [
              // Container(
              //   width: MediaQuery.of(context).size.width,
              //   padding: const EdgeInsets.all(20.0),
              //   color: Theme.of(context).primaryColorLight,
              //   child: Text("Appointments",
              //       style: Theme.of(context)
              //           .textTheme
              //           .bodyText1!
              //           .copyWith(fontSize: 13.5, color: Colors.grey)),
              // ),
              provider.isLoading
                  ? const Loading()
                  : ListView.builder(
                      itemCount: provider.appointmentList.length,
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12.0, vertical: 16),
                              child: Stack(
                                children: [
                                  Row(
                                    children: [
                                      CircleAvatar(
                                        radius: 25,
                                        backgroundImage: NetworkImage(
                                          context
                                              .read<DoctorsProvider>()
                                              .getDoctorImage(provider
                                                      .appointmentList[index]
                                                  ["doctorid"]),
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      const SizedBox(
                                        width: 12,
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            provider.appointmentList[index]
                                                ["doctorname"],
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodyText1!
                                                .copyWith(
                                                    fontWeight:
                                                        FontWeight.w600),
                                          ),
                                          const SizedBox(
                                            height: 4,
                                          ),
                                          Text(
                                            provider.appointmentList[index]
                                                ["purpose"],
                                            style: Theme.of(context)
                                                .textTheme
                                                .subtitle2!
                                                .copyWith(
                                                    fontSize: 12,
                                                    color: Theme.of(context)
                                                        .disabledColor),
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            "${provider.appointmentList[index]["date"]} | ${provider.appointmentList[index]["time"]}",
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodyText1!
                                                .copyWith(
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 13.5),
                                          )
                                        ],
                                      ),
                                    ],
                                  ),
                                  Align(
                                      alignment: Alignment.topRight,
                                      child: FadedScaleAnimation(
                                        child: Icon(
                                          Icons.more_vert,
                                          color: Theme.of(context).primaryColor,
                                          size: 18,
                                        ),
                                      )),
                                  PositionedDirectional(
                                      bottom: 0,
                                      end: 6,
                                      child: Row(
                                        children: [
                                          FadedScaleAnimation(
                                            child: provider.appointmentList[
                                                        index]["status"] ==
                                                    "completed"
                                                ? provider.appointmentList[
                                                                index]
                                                            ["ratingstatus"] ==
                                                        true
                                                    ? Row(
                                                        children: [
                                                          Text(provider
                                                              .appointmentList[
                                                                  index]
                                                                  ["rating"]
                                                              .toString()),
                                                          Icon(
                                                            Icons.star,
                                                            color: Colors
                                                                .amber.shade700,
                                                            size: 18,
                                                          ),
                                                        ],
                                                      )
                                                    : GestureDetector(
                                                        onTap: () {
                                                          review(
                                                            provider.appointmentList[
                                                                    index]
                                                                ["userid"],
                                                            provider.appointmentList[
                                                                    index]
                                                                ["doctorid"],
                                                            provider
                                                                .appointmentList[
                                                                    index]
                                                                .id,
                                                            provider.appointmentList[
                                                                index]["name"],
                                                            provider.appointmentList[
                                                                    index]
                                                                ["purpose"],
                                                          );
                                                        },
                                                        child:
                                                            FadedScaleAnimation(
                                                          child: Icon(
                                                            Icons.star_outline,
                                                            color: Colors
                                                                .amber.shade700,
                                                            size: 18,
                                                          ),
                                                        ),
                                                      )
                                                : const SizedBox(),
                                          ),
                                          const SizedBox(
                                            width: 18,
                                          ),
                                          GestureDetector(
                                            onTap: () {
                                              context
                                                  .read<AppointmentProvider>()
                                                  .selectedDocId = provider
                                                      .appointmentList[index]
                                                  ["doctorid"];
                                              context
                                                  .read<AppointmentProvider>()
                                                  .selectedUserId = provider
                                                      .appointmentList[index]
                                                  ["userid"];

                                              customPush(AppRoutes.CHATSCREEN);
                                            },
                                            child: FadedScaleAnimation(
                                              child: Icon(
                                                Icons.message,
                                                color: Theme.of(context)
                                                    .primaryColor,
                                                size: 18,
                                              ),
                                            ),
                                          )
                                        ],
                                      ))
                                ],
                              ),
                            ),
                            index + 1 != provider.appointmentList.length
                                ? const Divider(thickness: 8)
                                : const SizedBox.shrink(),
                          ],
                        );
                      }),
            ],
          );
        }));
  }
}
