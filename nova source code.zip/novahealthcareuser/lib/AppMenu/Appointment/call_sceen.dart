import 'package:agora_uikit/agora_uikit.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:doctoworld_doctor/providers/appointment_provider.dart';
import 'package:doctoworld_doctor/widgets/loading.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../utils/app_constants.dart';

class CallScreen extends StatefulWidget {
  const CallScreen({required this.channelId, Key? key}) : super(key: key);
  final String channelId;

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  AgoraClient? client;

  @override
  void initState() {
    super.initState();

    client = AgoraClient(
      agoraConnectionData: AgoraConnectionData(
        appId: AgoraConfig.appId,
        channelName: widget.channelId,
        tokenUrl: AgoraConfig.tokenBaseUrl,
      ),
    );

    initAgora();
  }

  void initAgora() async {
    await client!.initialize();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: client == null
          ? const Loading()
          : StreamBuilder<DocumentSnapshot>(
              stream: context
                  .read<AppointmentProvider>()
                  .collectionCalls
                  .doc(context.read<AppointmentProvider>().selectedUserId)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.data!.exists) {
                  client!.engine.leaveChannel();
                  if (!mounted) return const SizedBox();
                  // Navigator.pop(context);
                }
                if (snapshot.hasData && snapshot.data!.data() != null) {
                  return SafeArea(
                    child: Column(
                      children: [
                        Expanded(
                          child: Stack(
                            children: [
                              AgoraVideoViewer(client: client!),
                              AgoraVideoButtons(
                                client: client!,
                                disconnectButtonChild: IconButton(
                                  color: Colors.white,
                                  iconSize: 56.0,
                                  onPressed: () async {
                                    await client!.engine.leaveChannel();
                                    if (!mounted) return;

                                    context
                                        .read<AppointmentProvider>()
                                        .endCall();
                                    Navigator.pop(context);
                                  },
                                  icon: const Icon(
                                    Icons.call_end,
                                    color: Colors.red,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                } else {
                  return const SizedBox();
                }
              },
            ),
    );
  }
}
