import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:doctoworld_doctor/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:one_context/one_context.dart';
import 'package:provider/provider.dart';

import '../../models/call_model.dart';
import '../../providers/appointment_provider.dart';
import 'call_sceen.dart';

class CallPickupScreen extends StatefulWidget {
  final Widget scaffold;
  const CallPickupScreen({super.key, required this.scaffold});

  @override
  State<CallPickupScreen> createState() => _CallPickupScreenState();
}

class _CallPickupScreenState extends State<CallPickupScreen> {
  // AgoraClient? client;

  // @override
  // void initState() {
  //   super.initState();

  //   client = AgoraClient(
  //     agoraConnectionData: AgoraConnectionData(
  //       appId: AgoraConfig.appId,
  //       channelName: widget.channelId,
  //       tokenUrl: AgoraConfig.tokenBaseUrl,
  //     ),
  //   );

  //   initAgora();
  // }

  // void initAgora() async {
  //   await client!.initialize();
  // }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: context
          .read<AppointmentProvider>()
          .collectionCalls
          .doc(context.read<AppointmentProvider>().selectedUserId)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasData && snapshot.data!.data() != null) {
          Call call =
              Call.fromMap(snapshot.data!.data() as Map<String, dynamic>);

          if (!call.hasDialled) {
            return Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 48.0),
                  Text(
                    'Incoming Call',
                    style: Theme.of(context)
                        .textTheme
                        .headlineLarge
                        ?.copyWith(fontSize: 36.0),
                  ),
                  // const SizedBox(height: 48.0),
                  // const CircleAvatar(
                  //   radius: 64.0,
                  // ),
                  const SizedBox(height: 24.0),
                  Text(
                    call.callerName,
                    style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                        fontSize: 28.0,
                        fontWeight: FontWeight.w900,
                        color: Colors.black.withOpacity(0.7)),
                  ),
                  const SizedBox(height: 64.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        iconSize: 54.0,
                        onPressed: () async {
                          context.read<AppointmentProvider>().endCall();
                          // Navigator.pop(context);
                        },
                        icon: const Icon(
                          Icons.call_end,
                          color: Colors.red,
                        ),
                      ),
                      const SizedBox(width: 48.0),
                      IconButton(
                        iconSize: 54.0,
                        onPressed: () {
                          OneContext().push(
                            MaterialPageRoute(
                              builder: (_) => CallScreen(
                                channelId: call.callId,
                              ),
                            ),
                          );
                        },
                        icon: const Icon(
                          Icons.call,
                          color: primaryColor,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          }
        }
        return widget.scaffold;
      },
    );
  }
}
