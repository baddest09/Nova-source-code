import 'dart:async';
import 'package:doctoworld_doctor/AppMenu/Appointment/call_pickup_screen.dart';
import 'package:doctoworld_doctor/providers/appointment_provider.dart';
import 'package:doctoworld_doctor/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Chat extends StatefulWidget {
  const Chat({Key? key}) : super(key: key);

  @override
  State<Chat> createState() => _ChatState();
}

class _ChatState extends State<Chat> {
  final ScrollController _controller = ScrollController();
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final messageController = TextEditingController();

  @override
  void initState() {
    super.initState();

    Future.microtask(() => context.read<AppointmentProvider>().getAllChats(
        context.read<AppointmentProvider>().selectedUserId,
        context.read<AppointmentProvider>().selectedDocId));
  }

  Widget sentField() {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
          margin: const EdgeInsets.all(8.0),
          height: 61,
          child: Row(children: <Widget>[
            Expanded(
                child: Row(
              children: <Widget>[
                Expanded(
                  child: Form(
                    key: formKey,
                    child: TextFormField(
                      onTap: () {
                        if (_controller.hasClients) {
                          Timer(
                              const Duration(milliseconds: 200),
                              () => _controller.jumpTo(
                                  _controller.position.minScrollExtent));
                        }
                      },
                      controller: messageController,
                      decoration: InputDecoration(
                        contentPadding:
                            const EdgeInsets.symmetric(horizontal: 20),
                        filled: true,
                        hintText: "Type message",
                        border: OutlineInputBorder(
                          borderSide: const BorderSide(
                            color: Colors.transparent,
                          ),
                          borderRadius: BorderRadius.circular(100.0),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            color: Colors.transparent,
                          ),
                          borderRadius: BorderRadius.circular(100.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            color: Colors.transparent,
                          ),
                          borderRadius: BorderRadius.circular(100.0),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.all(15.0),
                  decoration: const BoxDecoration(
                      color: kMainColor, shape: BoxShape.circle),
                  child: InkWell(
                    child: const Icon(
                      Icons.send,
                      color: Colors.white,
                    ),
                    onTap: () {
                      context.read<AppointmentProvider>().sendChat(
                            messageController.text.trim(),
                            context.read<AppointmentProvider>().selectedUserId,
                            context.read<AppointmentProvider>().selectedDocId,
                          );

                      messageController.text = "";
                    },
                  ),
                )
              ],
            ))
          ])),
    );
  }

  @override
  Widget build(BuildContext context) {
    return CallPickupScreen(
      scaffold: Scaffold(
        appBar: AppBar(
          backgroundColor: primaryColor,
          title: const Text("Chat"),
          actions: [
            IconButton(
                onPressed: () {
                  context.read<AppointmentProvider>().createCall();
                },
                icon: const Icon(Icons.videocam_rounded))
          ],
        ),
        body: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          child: Stack(
            children: [
              Opacity(
                  opacity: 0.1,
                  child: Center(
                    child: Image.asset(
                      "assets/doctor_logo.png",
                      height: 300,
                    ),
                  )),
              Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  Consumer<AppointmentProvider>(
                      builder: (context, provider, __) {
                    return Flexible(
                      child: provider.chatList.isEmpty
                          ? const Center(
                              child: Text(
                                "Start chat with doctor",
                                style: TextStyle(fontSize: 18),
                              ),
                            )
                          : ListView.builder(
                              controller: _controller,
                              shrinkWrap: true,
                              reverse: true,
                              // physics: const NeverScrollableScrollPhysics(),
                              itemCount: provider.chatList.length,
                              padding:
                                  const EdgeInsets.only(top: 10, bottom: 10),
                              itemBuilder: (context, index) {
                                final message = provider.chatList[index];

                                return Container(
                                  padding: const EdgeInsets.only(
                                    left: 14,
                                    right: 14,
                                    top: 5,
                                    bottom: 5,
                                  ),
                                  child: Align(
                                    alignment: (message["senderId"] ==
                                            context
                                                .read<AppointmentProvider>()
                                                .selectedUserId
                                        ? Alignment.topRight
                                        : Alignment.topLeft),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: message["senderId"] ==
                                                context
                                                    .read<AppointmentProvider>()
                                                    .selectedUserId
                                            ? const BorderRadius.only(
                                                topLeft: Radius.circular(23),
                                                bottomRight:
                                                    Radius.circular(23),
                                                bottomLeft: Radius.circular(23))
                                            : const BorderRadius.only(
                                                topRight: Radius.circular(23),
                                                bottomLeft: Radius.circular(23),
                                                bottomRight:
                                                    Radius.circular(23)),
                                        color: (message["senderId"] !=
                                                context
                                                    .read<AppointmentProvider>()
                                                    .selectedUserId
                                            ? primaryColor
                                            : primaryColor),
                                      ),
                                      padding: const EdgeInsets.all(16),
                                      child: Text(
                                        message["message"],
                                        style: const TextStyle(
                                            fontSize: 15, color: Colors.white),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                    );
                  }),
                  sentField(),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
