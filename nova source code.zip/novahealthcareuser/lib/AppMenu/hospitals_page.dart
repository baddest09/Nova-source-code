// ignore_for_file: library_private_types_in_public_api

import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../Data/data.dart';
import '../providers/profile_provider.dart';
import '../utils/colors.dart';

class HospitalsHome extends StatefulWidget {
  const HospitalsHome({super.key});

  @override
  _HospitalsHomeState createState() => _HospitalsHomeState();
}

class _HospitalsHomeState extends State<HospitalsHome> {
  String? value = 'Wallington';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Spacer(),
            const Text("Nova Health Care",
                style: TextStyle(color: primaryColor)),
            const SizedBox(width: 5),
            Image.asset("assets/doctor_logo.png", height: 25),
            const Spacer(),
          ],
        ),
      ),
      // appBar: AppBar(
      //   title: const Text("Hospitals"),
      // ),
      body: const HospitalsBody(),
    );
  }
}

class HospitalsBody extends StatefulWidget {
  const HospitalsBody({super.key});

  @override
  _HospitalsBodyState createState() => _HospitalsBodyState();
}

class HospitalDetail {
  String image;
  String name;
  String type;
  String location;

  HospitalDetail(this.image, this.name, this.type, this.location);
}

class _HospitalsBodyState extends State<HospitalsBody> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        physics: const BouncingScrollPhysics(),
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(
                left: 20.0, top: 20, right: 20, bottom: 14),
            child: Text(
              "Hello" ',${context.read<ProfileProvider>().name},',
              style: Theme.of(context)
                  .textTheme
                  .subtitle2!
                  .copyWith(color: lightGreyColor, fontWeight: FontWeight.w500),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: FadedScaleAnimation(
              child: Text(
                "Find Hospitals",
                style: Theme.of(context)
                    .textTheme
                    .headline5!
                    .copyWith(fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16),
            child: TextFormField(
              onTap: () {
                //Navigator.pushNamed(context, PageRoutes.searchDoctors);
              },
              decoration: InputDecoration(
                  hintText: "Search Hospitals",
                  hintStyle: Theme.of(context)
                      .textTheme
                      .bodyText1!
                      .copyWith(color: textFieldColor, fontSize: 15),
                  prefixIcon: const Icon(
                    Icons.search,
                    size: 20,
                  ),
                  filled: true,
                  fillColor: Theme.of(context).backgroundColor,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide.none)),
            ),
          ),
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
            child: Row(
              children: [
                Text(
                  "Search by category",
                  style: Theme.of(context)
                      .textTheme
                      .bodyText1!
                      .copyWith(color: lightGreyColor, fontSize: 14.5),
                ),
                const Spacer(),
                Text(
                  "View all",
                  style: Theme.of(context).textTheme.bodyText1!.copyWith(
                      color: Theme.of(context).primaryColor, fontSize: 14.5),
                ),
              ],
            ),
          ),
          Container(
            height: 123.3,
            margin: const EdgeInsets.only(left: 10),
            child: ListView.builder(
                shrinkWrap: true,
                physics: const BouncingScrollPhysics(),
                scrollDirection: Axis.horizontal,
                itemCount: doctorCategories.length,
                itemBuilder: (context, index) {
                  return InkWell(
                    onTap: () {},
                    child: Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: FadedScaleAnimation(
                        child: Image.asset(
                          doctorCategories[index],
                          // height: 100,
                          width: 95,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  );
                }),
          ),
          const SizedBox(
            height: 5,
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20, right: 10, left: 16),
            child: Row(
              children: [
                Text(
                  "Hospitals near you",
                  style: Theme.of(context)
                      .textTheme
                      .bodyText1!
                      .copyWith(color: lightGreyColor, fontSize: 14.5),
                ),
                const Spacer(),
                IconButton(
                    icon: Icon(
                      Icons.map,
                      size: 20,
                      color: Theme.of(context).disabledColor,
                    ),
                    onPressed: () {})
              ],
            ),
          ),
          HospitalsList(),
        ],
      ),
    );
  }
}

class HospitalsList extends StatelessWidget {
  final List<HospitalDetail> _hospitals = [
    HospitalDetail('assets/ProfilePics/dp1.png', 'Apple Hospital',
        'General Hospital', 'Walter street, Wallington, New York.'),
    HospitalDetail('assets/ProfilePics/dp1.png', 'City Light Eye Care',
        'General Hospital', 'Jespora Bridge, Wallington, New York.'),
    HospitalDetail('assets/ProfilePics/dp1.png', 'Silver Soul Hospital',
        'General Hospital', 'Walter street, Wallington, New York.'),
    HospitalDetail('assets/ProfilePics/dp1.png', 'Apple Hospital',
        'General Hospital', 'Walter street, Wallington, New York.'),
    HospitalDetail('assets/ProfilePics/dp1.png', 'City Light Eye Care',
        'General Hospital', 'Jespora Bridge, Wallington, New York.'),
    HospitalDetail('assets/ProfilePics/dp1.png', 'Silver Soul Hospital',
        'General Hospital', 'Walter street, Wallington, New York.'),
  ];

  HospitalsList({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _hospitals.length,
      shrinkWrap: true,
      itemBuilder: (context, index) {
        return GestureDetector(
          onTap: () {},
          child: Column(
            children: [
              Divider(
                color: Theme.of(context).backgroundColor,
                thickness: 6,
              ),
              ListTile(
                contentPadding: const EdgeInsets.only(left: 16),
                title: Row(
                  children: [
                    Expanded(
                      // flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _hospitals[index].name,
                            style: Theme.of(context)
                                .textTheme
                                .bodyText1!
                                .copyWith(
                                    fontSize: 15,
                                    height: 1.5,
                                    color: black2,
                                    fontWeight: FontWeight.bold),
                          ),
                          Text(
                            _hospitals[index].type,
                            style: Theme.of(context)
                                .textTheme
                                .subtitle1!
                                .copyWith(
                                    fontSize: 11.7,
                                    color: const Color(0xff979797),
                                    height: 1.5),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: SizedBox(
                        height: 50,
                        width: MediaQuery.of(context).size.width / 2,
                        child: ListView.builder(
                          shrinkWrap: true,
                          physics: const BouncingScrollPhysics(),
                          scrollDirection: Axis.horizontal,
                          itemCount: stores.length,
                          itemBuilder: (context, index) {
                            return InkWell(
                              onTap: () {
                                //  Navigator.pushNamed(context, PageRoutes.medicines);
                              },
                              child: Padding(
                                padding: const EdgeInsets.only(left: 5),
                                child: FadedScaleAnimation(
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(5),
                                    child: Image.asset(
                                      stores[index],
                                      // height: 100,
                                      width: 90,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 14, right: 16.0, top: 15),
                child: Row(
                  children: [
                    Icon(
                      Icons.location_pin,
                      color: Theme.of(context).disabledColor,
                      size: 10,
                    ),
                    Expanded(
                      flex: 3,
                      child: Text(
                        _hospitals[index].location,
                        style: Theme.of(context).textTheme.bodyText2!.copyWith(
                            fontSize: 10,
                            color: Theme.of(context).disabledColor),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const Spacer(),
                    Icon(
                      Icons.call,
                      color: Theme.of(context).primaryColor,
                      size: 10,
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Text(
                      "Call Now",
                      style: Theme.of(context).textTheme.bodyText2!.copyWith(
                          fontSize: 10, color: Theme.of(context).primaryColor),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 8,
              )
            ],
          ),
        );
      },
    );
  }
}
//done
