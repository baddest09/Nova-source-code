// ignore_for_file: library_private_types_in_public_api

import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/Data/data.dart';
import 'package:doctoworld_doctor/providers/doctors_provider.dart';
import 'package:doctoworld_doctor/translations/locale_keys.g.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/profile_provider.dart';
import '../../router/app_router.dart';
import '../../utils/colors.dart';

class OurDoctors extends StatefulWidget {
  const OurDoctors({super.key});

  @override
  _OurDoctorsState createState() => _OurDoctorsState();
}

class _OurDoctorsState extends State<OurDoctors> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => context.read<DoctorsProvider>().getLocation());
    Future.microtask(() => context.read<ProfileProvider>().getCurrentUser());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        titleSpacing: 0,
        leadingWidth: 35,
        leading: Icon(
          Icons.location_on,
          size: 18,
          color: Theme.of(context).primaryColor,
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              context.read<DoctorsProvider>().address,
              style: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .copyWith(fontSize: 14, fontWeight: FontWeight.w700),
              overflow: TextOverflow.ellipsis,
            ),
            // const Spacer(),
            // const Text("Nova HealthCare",
            //     style: TextStyle(color: primaryColor)),
            // const Spacer(),
            // const Spacer()
          ],
        ),
        // actions: <Widget>[
        //   Stack(
        //     children: [
        //       IconButton(
        //         icon: const Icon(
        //           Icons.shopping_cart,
        //           // color: Colors.black,
        //         ),
        //         onPressed: () {},
        //       ),
        //       Positioned.directional(
        //         textDirection: Directionality.of(context),
        //         top: 8,
        //         end: 12,
        //         child: CircleAvatar(
        //           backgroundColor: Colors.red,
        //           radius: 5.5,
        //           child: Center(
        //               child: Text(
        //             '1',
        //             style: Theme.of(context).textTheme.bodyText2!.copyWith(
        //                 color: Theme.of(context).scaffoldBackgroundColor,
        //                 fontSize: 9),
        //           )),
        //         ),
        //       )
        //     ],
        //   ),
        // ],
      ),
      body: FadedSlideAnimation(
        beginOffset: const Offset(0, 0.3),
        endOffset: const Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
        child: const DoctorsBody(),
      ),
    );
  }
}

class DoctorsBody extends StatefulWidget {
  const DoctorsBody({super.key});

  @override
  _DoctorsBodyState createState() => _DoctorsBodyState();
}

class _DoctorsBodyState extends State<DoctorsBody> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        physics: const BouncingScrollPhysics(),
        children: <Widget>[
          Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 20.0, top: 20, right: 20, bottom: 14),
                    child: Text(
                      "Hello" ', ${context.read<ProfileProvider>().name},',
                      style: Theme.of(context).textTheme.subtitle2!.copyWith(
                          color: lightGreyColor, fontWeight: FontWeight.w500),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: FadedScaleAnimation(
                      child: Text(
                        "Find Doctors",
                        style: Theme.of(context)
                            .textTheme
                            .headline5!
                            .copyWith(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: Image.asset("assets/doctor_logo.png", height: 50),
              ),
            ],
          ),
          const SizedBox(
            height: 25,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16),
            child: TextFormField(
              // readOnly: true,
              onTap: () {
                // Navigator.pushNamed(context, PageRoutes.searchDoctors);
              },
              decoration: InputDecoration(
                  hintText: "Search Doctors",
                  hintStyle: Theme.of(context)
                      .textTheme
                      .bodyText1!
                      .copyWith(color: textFieldColor, fontSize: 15),
                  prefixIcon: const Icon(
                    Icons.search,
                    size: 20,
                  ),
                  filled: true,
                  fillColor: Theme.of(context).backgroundColor,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide.none)),
            ),
          ),
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
            child: Row(
              children: [
                Text(
                  "Find by specialities",
                  style: Theme.of(context)
                      .textTheme
                      .bodyText1!
                      .copyWith(color: lightGreyColor, fontSize: 14.5),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    Navigator.pushNamed(context, AppRoutes.listOfDoctors);
                  },
                  child: Text(
                    "View all",
                    style: Theme.of(context).textTheme.bodyText1!.copyWith(
                        color: Theme.of(context).primaryColor, fontSize: 14.5),
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 123.3,
            margin: const EdgeInsets.only(left: 10),
            child: ListView.builder(
                shrinkWrap: true,
                physics: const BouncingScrollPhysics(),
                scrollDirection: Axis.horizontal,
                itemCount: doctorCategories.length,
                itemBuilder: (context, index) {
                  return InkWell(
                    onTap: () {
                      Navigator.pushNamed(context, AppRoutes.listOfDoctors);
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: FadedScaleAnimation(
                        child: Image.asset(
                          doctorCategories[index],
                          // height: 100,
                          width: 95,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  );
                }),
          ),
          const SizedBox(
            height: 5,
          ),
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
            child: Text(
              "Sponser ad",
              style: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .copyWith(color: lightGreyColor, fontSize: 14.5),
            ),
          ),
          SizedBox(
            height: 110,
            child: ListView.builder(
                shrinkWrap: true,
                physics: const BouncingScrollPhysics(),
                scrollDirection: Axis.horizontal,
                itemCount: doctorBanners.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: FadedScaleAnimation(
                      child: Image.asset(
                        doctorBanners[index],
                        width: 250,
                      ),
                    ),
                  );
                }),
          ),
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
            child: Text(
              LocaleKeys.listOfSpecialities.tr(),
              style: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .copyWith(color: lightGreyColor, fontSize: 14.5),
            ),
          ),
          ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: specialities.length,
            itemBuilder: (context, index) {
              return Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                child: Row(
                  children: [
                    Text(
                      specialities[index],
                      style: Theme.of(context).textTheme.bodyText2!.copyWith(
                          fontSize: 13.3,
                          color: black2,
                          fontWeight: FontWeight.w600),
                    ),
                    const Spacer(),
                    const Icon(
                      Icons.arrow_forward_ios,
                      size: 15,
                      color: Color(0xffb3b3b3),
                    ),
                  ],
                ),
              );
              /*ListTile(
                contentPadding: EdgeInsets.symmetric(),
                title: Text('Addiction psychiatrist'),
                trailing: Icon(Icons.arrow_forward_ios, size: 15,),
              );*/
            },
          ),
        ],
      ),
    );
  }
}
