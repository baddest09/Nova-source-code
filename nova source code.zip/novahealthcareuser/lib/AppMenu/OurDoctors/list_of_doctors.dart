// ignore_for_file: library_private_types_in_public_api

import 'dart:core';

import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/AppMenu/OurDoctors/doctor_info.dart';
import 'package:doctoworld_doctor/providers/doctors_provider.dart';
import 'package:doctoworld_doctor/translations/locale_keys.g.dart';
import 'package:doctoworld_doctor/widgets/loading.dart';
import 'package:easy_localization/easy_localization.dart';

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:one_context/one_context.dart';
import 'package:provider/provider.dart';

class DoctorsPage extends StatefulWidget {
  const DoctorsPage({super.key});

  @override
  _DoctorsPageState createState() => _DoctorsPageState();
}

class _DoctorsPageState extends State<DoctorsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: IconButton(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.chevron_left)),
          centerTitle: true,
          title: Text(LocaleKeys.doctors.tr()),
          toolbarTextStyle: Theme.of(context).textTheme.bodyText2,
          titleTextStyle: Theme.of(context).textTheme.headline6,
        ),
        body: FadedSlideAnimation(
          beginOffset: const Offset(0, 0.3),
          endOffset: const Offset(0, 0),
          slideCurve: Curves.linearToEaseOut,
          child: const DoctorsList(),
        ));
  }
}

class DoctorsList extends StatefulWidget {
  const DoctorsList({super.key});

  @override
  _DoctorsListState createState() => _DoctorsListState();
}

class SearchDoctorTile {
  String image;
  String name;
  String? speciality;
  String hospital;
  String experience;
  String fee;
  String reviews;

  SearchDoctorTile(this.image, this.name, this.speciality, this.hospital,
      this.experience, this.fee, this.reviews);
}

class _DoctorsListState extends State<DoctorsList> {
  @override
  void initState() {
    super.initState();

    Future.microtask(
      () => context.read<DoctorsProvider>().getDoctors(),
    );
  }

  @override
  Widget build(BuildContext context) {
    // List<SearchDoctorTile> searchList = [
    //   SearchDoctorTile('assets/doctors/doc1.png', 'Dr. Joseph Will',
    //       LocaleKeys.cardiacSurgeon.tr(), 'Apple Hospital', '22', '30', '152'),
    //   SearchDoctorTile('assets/doctors/doc2.png', 'Dr. Anglina',
    //       LocaleKeys.cardiacSurgeon.tr(), 'Operum Clinics', '22', '30', '201'),
    //   SearchDoctorTile('assets/doctors/doc3.png', 'Dr. Anthony',
    //       LocaleKeys.cardiacSurgeon.tr(), 'Opus Hospital', '22', '30', '135'),
    //   SearchDoctorTile(
    //       'assets/doctors/doc4.png',
    //       'Dr. Elina',
    //       LocaleKeys.cardiacSurgeon.tr(),
    //       'Lismuth Hospital',
    //       '22',
    //       '30',
    //       '438'),
    //   SearchDoctorTile('assets/doctors/doc1.png', 'Dr. Joseph',
    //       LocaleKeys.cardiacSurgeon.tr(), 'Apple Hospital', '22', '30', '152'),
    //   SearchDoctorTile('assets/doctors/doc2.png', 'Dr. Anglina',
    //       LocaleKeys.cardiacSurgeon.tr(), 'Operum Clinics', '22', '30', '201'),
    //   SearchDoctorTile('assets/doctors/doc3.png', 'Dr. Anthony',
    //       LocaleKeys.cardiacSurgeon.tr(), 'Opus Hospital', '22', '30', '135'),
    //   SearchDoctorTile(
    //       'assets/doctors/doc4.png',
    //       'Dr. Elina',
    //       LocaleKeys.cardiacSurgeon.tr(),
    //       'Lismuth Hospital',
    //       '22',
    //       '30',
    //       '438'),
    // ];
    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 0),
        physics: const BouncingScrollPhysics(),
        shrinkWrap: true,
        children: [
          const Divider(
            thickness: 6,
            height: 6,
          ),
          Consumer<DoctorsProvider>(builder: (context, provider, __) {
            return provider.isLoading
                ? const Loading()
                : ListView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: provider.doctorList.length,
                    itemBuilder: (context, index) {
                      return Stack(
                        children: [
                          Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 8, bottom: 18.0, left: 8, right: 8),
                                child: GestureDetector(
                                  onTap: () {
                                    OneContext().push(
                                      MaterialPageRoute(
                                        builder: (_) => DoctorInfo(
                                          doctor: provider.doctorList,
                                          index: index,
                                        ),
                                      ),
                                    );
                                    // Navigator.pushNamed(
                                    //     context, AppRoutes.doctorInfoPage);
                                  },
                                  child: Row(
                                    children: [
                                      CircleAvatar(
                                        radius: 25,
                                        backgroundImage: NetworkImage(
                                          provider.doctorList[index]["image"],
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          const SizedBox(
                                            height: 12,
                                          ),
                                          RichText(
                                              text: TextSpan(
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .subtitle2,
                                                  children: <TextSpan>[
                                                TextSpan(
                                                    text:
                                                        '${provider.doctorList[index]["name"]}\n',
                                                    style: Theme.of(context)
                                                        .textTheme
                                                        .subtitle1!
                                                        .copyWith(
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold)),
                                                TextSpan(
                                                  text:
                                                      provider.doctorList[index]
                                                          ["specifications"][0],
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .bodyText2!
                                                      .copyWith(
                                                          color: Theme.of(
                                                                  context)
                                                              .disabledColor,
                                                          fontSize: 12),
                                                ),
                                              ])),
                                          const SizedBox(
                                            height: 15,
                                          ),
                                          Row(
                                            children: [
                                              Text(
                                                '${LocaleKeys.exp.tr()}. ',
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .subtitle2!
                                                    .copyWith(
                                                        color: Theme.of(context)
                                                            .disabledColor,
                                                        fontSize: 12),
                                              ),
                                              Text(
                                                '${provider.doctorList[index]["experience"]} ${LocaleKeys.years.tr()}',
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .subtitle1!
                                                    .copyWith(fontSize: 12),
                                              ),
                                              const SizedBox(
                                                width: 12,
                                              ),
                                              Text(
                                                '${LocaleKeys.fees.tr()} ',
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .subtitle2!
                                                    .copyWith(
                                                        color: Theme.of(context)
                                                            .disabledColor,
                                                        fontSize: 12),
                                              ),
                                              Text(
                                                '\$${provider.doctorList[index]["fees"]}',
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .subtitle1!
                                                    .copyWith(fontSize: 12),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const Divider(
                                height: 6,
                                thickness: 6,
                              ),
                            ],
                          ),
                          PositionedDirectional(
                            end: 4,
                            bottom: 28,
                            child: Row(
                              children: [
                                RatingBar.builder(
                                    tapOnlyMode: true,
                                    itemSize: 12,
                                    initialRating: provider.doctorList[index]
                                            ["stars"]
                                        .toDouble(),
                                    direction: Axis.horizontal,
                                    itemCount: 5,
                                    itemBuilder: (context, _) => const Icon(
                                          Icons.star,
                                          color: Colors.amber,
                                        ),
                                    onRatingUpdate: (rating) {}),
                                // const SizedBox(
                                //   width: 4,
                                // ),
                                // Text(
                                //   '(${provider.doctorList[index]["fees"]})',
                                //   style: Theme.of(context)
                                //       .textTheme
                                //       .subtitle2!
                                //       .copyWith(
                                //           fontSize: 10,
                                //           color: Theme.of(context).disabledColor),
                                // ),
                              ],
                            ),
                          ),
                        ],
                      );
                    },
                  );
          }),
        ],
      ),
    );
  }
}
