// ignore_for_file: library_private_types_in_public_api

import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/router/app_router.dart';
import 'package:doctoworld_doctor/translations/locale_keys.g.dart';
import 'package:doctoworld_doctor/utils/navigates.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class AppointmentBooked extends StatefulWidget {
  const AppointmentBooked({super.key});

  @override
  _AppointmentBookedState createState() => _AppointmentBookedState();
}

class _AppointmentBookedState extends State<AppointmentBooked> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.chevron_left)),
        title: Text(LocaleKeys.appointmentBooked.tr()),
        automaticallyImplyLeading: false,
        centerTitle: true,
      ),
      body: FadedSlideAnimation(
        beginOffset: const Offset(0, 0.3),
        endOffset: const Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Spacer(),
            Expanded(
              flex: 5,
              child: FadedScaleAnimation(
                child: Image.asset(
                  'assets/order placed.png',
                  // scale: 3,
                ),
              ),
            ),
            const Spacer(),
            Center(
                child: Text(
              '${LocaleKeys.yourAppointmentHas.tr()}\n${LocaleKeys.beenBooked.tr()}',
              style:
                  Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 18),
              textAlign: TextAlign.center,
            )),
            // const Spacer(),
            // Center(
            //     child: Text(
            //         '${LocaleKeys.appointmentDetails.tr()}\n${LocaleKeys.hasBeenSentOnYourGiven.tr()}\n${LocaleKeys.number.tr()}',
            //         style: Theme.of(context)
            //             .textTheme
            //             .caption!
            //             .copyWith(fontSize: 16),
            //         textAlign: TextAlign.center)),
            const Spacer(
              flex: 3,
            ),
            Center(
                child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: InkWell(
                  onTap: () {
                    customPushAndRemoveUntill(AppRoutes.NAVIG);
                    // Navigator.pushNamed(context, PageRoutes.appMenu);
                  },
                  child: Text(
                    LocaleKeys.home.tr(),
                    style: Theme.of(context).textTheme.bodyText1!.copyWith(
                        fontSize: 16, color: Theme.of(context).primaryColor),
                  )),
            ))
          ],
        ),
      ),
    );
  }
}
