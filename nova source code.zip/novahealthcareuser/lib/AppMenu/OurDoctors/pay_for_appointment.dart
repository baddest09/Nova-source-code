// ignore_for_file: avoid_print, use_build_context_synchronously

import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:dio/dio.dart';
import 'package:doctoworld_doctor/utils/snackbar.dart';
import 'package:doctoworld_doctor/widgets/loading.dart';
import 'package:flutter/material.dart';
import 'package:one_context/one_context.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../providers/appointment_provider.dart';

class Payment extends StatefulWidget {
  final String doctorIdSelected;
  final String doctorNameSelected;
  final String date;
  final String selectedTime;
  final String purpose;
  final String name;

  const Payment(
      {super.key,
      required this.doctorIdSelected,
      required this.doctorNameSelected,
      required this.date,
      required this.selectedTime,
      required this.purpose,
      required this.name});

  @override
  State<Payment> createState() => _PaymentState();
}

class _PaymentState extends State<Payment> with WidgetsBindingObserver {
  final Completer<WebViewController> _controller =
      Completer<WebViewController>();
  bool isLoading = true;
  String baseUrl = "https://cybqa.pesapal.com/pesapalv3";
  String consumerKey = "wCGzX1fNzvtI5lMR5M4AxvxBmLpFgZzp";
  String consumerSecret = "uU7R9g2IHn9dkrKDVIfcPppktIo=";
  String token = "";
  String orderTrackingId = "";
  String webViewUrl = "";
  String orderId = "";
  Dio dio = Dio();

  @override
  void initState() {
    super.initState();
    if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
    orderId = ordercode(8);
    call();
  }

  String ordercode(int len) {
    var r = Random.secure();
    const chars = '1234567890987654321';
    return List.generate(len, (index) => chars[r.nextInt(chars.length)])
        .join()
        .toString();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future call() async {
    setState(() => isLoading = true);
    await getToken();
  }

  Future getToken() async {
    try {
      var response = await dio.post('$baseUrl/api/Auth/RequestToken',
          options: Options(
            headers: {
              "Content-Type": "application/json",
              "Accept": "application/json",
            },
          ),
          data: {
            "consumer_key": consumerKey,
            "consumer_secret": consumerSecret
          });

      if (response.statusCode == 200) {
        print(response.data);
        if (response.data["token"] != "") {
          debugPrint(token);
          setState(() {
            token = response.data["token"];
          });
          registerIPN();
        }
      }
    } catch (e) {
      print(e);
    }
  }

  void registerIPN() async {
    try {
      var response = await dio.post('$baseUrl/api/URLSetup/RegisterIPN',
          options: Options(
            headers: {
              "Content-Type": "application/json",
              "Accept": "application/json",
              "Authorization": "Bearer $token"
            },
          ),
          data: {
            "url": "https://www.myapplication.com/ipn",
            "ipn_notification_type": "GET"
          });

      if (response.statusCode == 200) {
        debugPrint("ipn_id -------> ${response.data["ipn_id"]} ");
        submitOrderRequest(response.data["ipn_id"]);
      }
    } catch (e) {
      print(e);
    }
  }

  void submitOrderRequest(String ipnid) async {
    try {
      var response = await dio.post(
        '$baseUrl/api/Transactions/SubmitOrderRequest',
        options: Options(
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": "Bearer $token"
          },
        ),
        data: {
          "id": orderId,
          "currency": "USD",
          "amount": 10,
          "description": "Doctor appointment fees",
          "callback_url": "https://www.myapplication.com/response-page",
          "notification_id": ipnid,
          "billing_address": {
            "email_address": "john.doe@example.com",
            "phone_number": null,
            "country_code": "",
            "first_name": "John",
            "middle_name": "",
            "last_name": "Doe",
            "line_1": "",
            "line_2": "",
            "city": "",
            "state": "",
            "postal_code": null,
            "zip_code": null
          }
        },
      );

      if (response.statusCode == 200) {
        debugPrint("redirect_url -------> ${response.data} ");

        setState(() {
          webViewUrl = response.data["redirect_url"];
          orderTrackingId = response.data["order_tracking_id"];
          isLoading = false;
        });
      }
    } catch (e) {
      print(e);
    }
  }

  void checkStatus() async {
    try {
      var response = await dio.get(
        '$baseUrl/api/Transactions/GetTransactionStatus?orderTrackingId=$orderTrackingId',
        options: Options(
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": "Bearer $token"
          },
        ),
      );

      if (response.statusCode == 200) {
        if (response.data["message"] == "Request processed successfully") {
          context.read<AppointmentProvider>().bookAppointment(
                widget.doctorIdSelected,
                widget.doctorNameSelected,
                widget.date,
                widget.selectedTime,
                widget.purpose,
                widget.name,
                // phonecontroller.text.trim(),
              );
        } else {
          NotificationsService.showSnackbar(
              "Payment not successfull try again");
          OneContext().pushReplacement(
            MaterialPageRoute(
              builder: (_) => Payment(
                doctorIdSelected: widget.doctorIdSelected,
                doctorNameSelected: widget.doctorNameSelected,
                date: widget.date,
                selectedTime: widget.selectedTime,
                purpose: widget.purpose,
                name: widget.name,
              ),
            ),
          );
        }
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: isLoading
          ? const Loading()
          : WebView(
              initialUrl: webViewUrl,
              javascriptMode: JavascriptMode.unrestricted,
              zoomEnabled: true,
              gestureNavigationEnabled: true,
              onWebViewCreated: (WebViewController webViewController) {
                _controller.complete(webViewController);
              },
              onPageStarted: (String url) {},
              onPageFinished: (finish) {},
              onWebResourceError: (error) async {
                debugPrint(
                    'MyWebViewWidget:onWebResourceError(): ${error.description}');
              },
              navigationDelegate: (NavigationRequest request) {
                print('Navigating to ${request.url}');

                if (request.url.startsWith(
                    "https://cybqa.pesapal.com/PesapalIframe/PesapalIframe3/PaymentConfirmation?Order_Tracking_Id=")) {
                  setState(() {
                    isLoading = true;
                  });

                  checkStatus();

                  return NavigationDecision.navigate;
                } else {
                  return NavigationDecision.prevent;
                }
              },
            ),
    );
  }
}
