// ignore_for_file: library_private_types_in_public_api

import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/providers/doctors_provider.dart';
import 'package:doctoworld_doctor/router/app_router.dart';
import 'package:doctoworld_doctor/translations/locale_keys.g.dart';
import 'package:doctoworld_doctor/utils/navigates.dart';
import 'package:easy_localization/easy_localization.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../utils/colors.dart';
import '../../widgets/custom_button.dart';

class DoctorInfo extends StatefulWidget {
  final List doctor;
  final int index;
  const DoctorInfo({super.key, required this.doctor, required this.index});

  @override
  _DoctorInfoState createState() => _DoctorInfoState();
}

class _DoctorInfoState extends State<DoctorInfo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: FadedSlideAnimation(
        beginOffset: const Offset(0, 0.3),
        endOffset: const Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
        child: Stack(
          children: [
            Container(
              color: Theme.of(context).backgroundColor,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  Container(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 20.0),
                              child: FadedScaleAnimation(
                                child: Image.network(
                                  widget.doctor[widget.index]["image"],
                                  height: 120,
                                  width: 100,
                                ),
                              ),
                            ),
                            const Spacer(),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(
                                  height: 45,
                                ),
                                RichText(
                                  text: TextSpan(
                                      style:
                                          Theme.of(context).textTheme.subtitle2,
                                      children: [
                                        TextSpan(
                                            text:
                                                '${LocaleKeys.experience.tr()}\n',
                                            style: Theme.of(context)
                                                .textTheme
                                                .subtitle2!
                                                .copyWith(
                                                  color: Theme.of(context)
                                                      .disabledColor,
                                                  fontSize: 13,
                                                )),
                                        TextSpan(
                                            text:
                                                '${widget.doctor[widget.index]["experience"]} ${LocaleKeys.yearsPascal.tr()}',
                                            style: const TextStyle(height: 1.4))
                                      ]),
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                RichText(
                                  text: TextSpan(
                                      style:
                                          Theme.of(context).textTheme.subtitle2,
                                      children: [
                                        TextSpan(
                                            text:
                                                '${LocaleKeys.consultancyFees.tr()}\n',
                                            style: Theme.of(context)
                                                .textTheme
                                                .subtitle2!
                                                .copyWith(
                                                    color: Theme.of(context)
                                                        .disabledColor,
                                                    fontSize: 13)),
                                        TextSpan(
                                            text:
                                                '\$${widget.doctor[widget.index]["fees"]}',
                                            style: const TextStyle(height: 1.4))
                                      ]),
                                ),
                              ],
                            ),
                            const Spacer(
                              flex: 2,
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 20, top: 10, bottom: 20, right: 20),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                text: TextSpan(
                                    style:
                                        Theme.of(context).textTheme.subtitle2,
                                    children: [
                                      TextSpan(
                                          text:
                                              'Dr.\n${widget.doctor[widget.index]["name"]}\n\n',
                                          style: Theme.of(context)
                                              .textTheme
                                              .subtitle2!
                                              .copyWith(fontSize: 26)),
                                      TextSpan(
                                          text: LocaleKeys.cardiacSurgeon.tr(),
                                          style: Theme.of(context)
                                              .textTheme
                                              .subtitle2!
                                              .copyWith(
                                                  color: Theme.of(context)
                                                      .disabledColor,
                                                  fontSize: 13))
                                    ]),
                              ),
                              const Spacer(),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    LocaleKeys.feedbacks.tr(),
                                    style: Theme.of(context)
                                        .textTheme
                                        .subtitle2!
                                        .copyWith(
                                            color:
                                                Theme.of(context).disabledColor,
                                            fontSize: 16),
                                  ),
                                  const SizedBox(
                                    height: 4,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      // Navigator.pushNamed(
                                      //     context, PageRoutes.doctorReviewPage);
                                    },
                                    child: Row(
                                      children: [
                                        const Icon(
                                          Icons.star,
                                          color: starColor,
                                          size: 15,
                                        ),
                                        const SizedBox(
                                          width: 2,
                                        ),
                                        Text(
                                          widget.doctor[widget.index]["stars"]
                                              .toString(),
                                          style: Theme.of(context)
                                              .textTheme
                                              .subtitle1!
                                              .copyWith(
                                                  fontSize: 15,
                                                  color: starColor),
                                        ),
                                        // const SizedBox(
                                        //   width: 4,
                                        // ),
                                        // Text(
                                        //   '(124)',
                                        //   style: Theme.of(context)
                                        //       .textTheme
                                        //       .subtitle1!
                                        //       .copyWith(
                                        //           color: Theme.of(context)
                                        //               .disabledColor,
                                        //           fontSize: 15),
                                        // ),
                                        const SizedBox(
                                          width: 50,
                                        ),
                                        Icon(
                                          Icons.arrow_forward_ios_rounded,
                                          color:
                                              Theme.of(context).disabledColor,
                                          size: 15,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  Row(
                                    children: [
                                      Text(
                                        LocaleKeys.availability.tr(),
                                        style: Theme.of(context)
                                            .textTheme
                                            .subtitle2!
                                            .copyWith(
                                                color: Theme.of(context)
                                                    .disabledColor,
                                                fontSize: 15),
                                      ),
                                      const SizedBox(
                                        width: 60,
                                      ),
                                      Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        color: Theme.of(context).disabledColor,
                                        size: 15,
                                      ),
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 4,
                                  ),
                                  RichText(
                                    text: TextSpan(
                                        style: Theme.of(context)
                                            .textTheme
                                            .subtitle1,
                                        children: [
                                          TextSpan(
                                              text: '12:00  to  13:00',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .subtitle2!
                                                  .copyWith(fontSize: 14))
                                        ]),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Divider(
                    thickness: 6,
                    height: 6,
                  ),
                  Container(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    padding: const EdgeInsets.only(
                        top: 10, left: 20, bottom: 20, right: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          LocaleKeys.services.tr(),
                          style: Theme.of(context)
                              .textTheme
                              .subtitle1!
                              .copyWith(color: Theme.of(context).disabledColor),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        SizedBox(
                          height: 200,
                          child: ListView.builder(
                            shrinkWrap: true,
                            itemCount:
                                widget.doctor[widget.index]["services"].length,
                            itemBuilder: (BuildContext context, int index) {
                              return Text(
                                widget.doctor[widget.index]["services"][index],
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText2!
                                    .copyWith(fontSize: 15, height: 2),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Divider(
                    thickness: 6,
                    height: 6,
                  ),
                  Container(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    padding:
                        const EdgeInsets.only(top: 10, left: 20, bottom: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          LocaleKeys.sprecifications.tr(),
                          style: Theme.of(context)
                              .textTheme
                              .subtitle1!
                              .copyWith(color: Theme.of(context).disabledColor),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        SizedBox(
                          height: 200,
                          child: ListView.builder(
                            shrinkWrap: true,
                            itemCount: widget
                                .doctor[widget.index]["specifications"].length,
                            itemBuilder: (BuildContext context, int index) {
                              return Text(
                                widget.doctor[widget.index]["specifications"]
                                    [index],
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText2!
                                    .copyWith(fontSize: 15, height: 2),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Divider(
                    thickness: 6,
                    height: 6,
                  ),
                  const SizedBox(
                    height: 60,
                  )
                ],
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: CustomButton(
                onTap: () {
                  context.read<DoctorsProvider>().doctorNameSelected =
                      widget.doctor[widget.index]["name"];
                  context.read<DoctorsProvider>().doctorIdSelected =
                      widget.doctor[widget.index].id;
                  customPush(AppRoutes.bookAppointmentPage);
                  // Navigator.pushNamed(context, PageRoutes.bookAppointmentPage);
                },
                // icon: Icon(
                //   Icons.calendar_today_rounded,
                //   color: Colors.white,
                //   size: 16,
                // ),
                text: LocaleKeys.bookAppointmentNow.tr(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
