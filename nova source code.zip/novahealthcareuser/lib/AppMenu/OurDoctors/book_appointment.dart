// ignore_for_file: library_private_types_in_public_api

import 'dart:math';

import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:calendar_timeline/calendar_timeline.dart';
import 'package:doctoworld_doctor/AppMenu/OurDoctors/pay_for_appointment.dart';
import 'package:doctoworld_doctor/providers/appointment_provider.dart';
import 'package:doctoworld_doctor/translations/locale_keys.g.dart';
import 'package:doctoworld_doctor/utils/helperfunctions.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:one_context/one_context.dart';
import 'package:provider/provider.dart';
import '../../providers/doctors_provider.dart';
import '../../utils/colors.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/entry_field2.dart';

class BookAppointmentPage extends StatefulWidget {
  const BookAppointmentPage({super.key});

  @override
  _BookAppointmentPageState createState() => _BookAppointmentPageState();
}

class _BookAppointmentPageState extends State<BookAppointmentPage> {
  final namecontroller = TextEditingController();
  final phonecontroller = TextEditingController();
  final purposecontroller = TextEditingController();
  final codeController = TextEditingController();
  final List<String> day = [
    'Mon',
    'Tues',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
    'Mon',
    'Tues',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
    'Mon',
    'Tues',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
    'Mon',
    'Tues',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
  ];
  final List<String> time = [
    '7:00 AM',
    '8:00 AM',
    '9:00 AM',
    '10:00 AM',
    '11:00 AM',
  ];
  // int? _selectedDate;
  String? _selectedTime;
  DateTime _selectedDate = DateTime.now();

  String chars =
      'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
  Random rnd = Random();
  String getRandomString() => String.fromCharCodes(
      Iterable.generate(4, (_) => chars.codeUnitAt(rnd.nextInt(chars.length))));
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.chevron_left)),
        title: Text(LocaleKeys.selectDateTime.tr()),
        centerTitle: true,
      ),
      body: FadedSlideAnimation(
        beginOffset: const Offset(0, 0.3),
        endOffset: const Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
        child: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: Row(
                      children: [
                        Text(
                          LocaleKeys.selectDate.tr(),
                          style: Theme.of(context)
                              .textTheme
                              .caption!
                              .copyWith(fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                  CalendarTimeline(
                    showYears: true,
                    initialDate: _selectedDate,
                    firstDate: DateTime.now(),
                    lastDate: DateTime(2025, 12, 30),
                    onDateSelected: (date) =>
                        setState(() => _selectedDate = date),
                    leftMargin: 20,
                    monthColor: Theme.of(context).primaryColor,
                    dayColor: Theme.of(context).primaryColor,
                    // dayNameColor: const Color(0xFF333A47),
                    activeDayColor: Colors.white,
                    activeBackgroundDayColor: Theme.of(context).primaryColor,
                    // dotsColor: const Color(0xFF333A47),
                    // selectableDayPredicate: (date) => date.day != 23,
                    // locale: 'en',
                  ),
                  const SizedBox(height: 4),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20.0, vertical: 8),
                    child: Text(
                      LocaleKeys.selectTime.tr(),
                      style: Theme.of(context)
                          .textTheme
                          .caption!
                          .copyWith(fontSize: 16),
                    ),
                  ),
                  SizedBox(
                    height: 70,
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 12),
                      scrollDirection: Axis.horizontal,
                      shrinkWrap: true,
                      itemCount: time.length,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            setState(
                              () {
                                _selectedTime = time[index];
                              },
                            );
                          },
                          child: FadedScaleAnimation(
                            child: Container(
                              margin:
                                  const EdgeInsets.only(right: 6, bottom: 8),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                color: _selectedTime == time[index]
                                    ? Theme.of(context).primaryColor
                                    : const Color(0xfff8f9fd),
                              ),
                              child: RichText(
                                text: TextSpan(
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: time[index],
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyText1!
                                          .copyWith(
                                            fontSize: 18,
                                            color: _selectedTime == time[index]
                                                ? Colors.white
                                                : Colors.black,
                                          ),
                                    ),
                                    TextSpan(
                                      text: ' ${LocaleKeys.am.tr()}',
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyText1!
                                          .copyWith(
                                            fontSize: 11,
                                            color: _selectedTime == time[index]
                                                ? Theme.of(context)
                                                    .scaffoldBackgroundColor
                                                : dayTimeTextColor,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 12,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 12.0, right: 20.0, bottom: 28.0),
                    child: EntryField2(
                      label: LocaleKeys.appointmentFor.tr(),
                      hint: LocaleKeys.egHeart.tr(),
                      textEditingController: purposecontroller,
                    ),
                  ),
                  const Divider(
                    height: 6,
                    thickness: 6,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 12.0, right: 20.0, bottom: 20.0, top: 28.0),
                    child: EntryField2(
                      label: LocaleKeys.fullName.tr(),
                      textEditingController: namecontroller,
                    ),
                  ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Row(
                children: [
                  Flexible(
                    child: CustomButton(
                      text: "Confirm by payment",
                      onTap: () {
                        String date =
                            convertDateTimeDisplay(_selectedDate.toString());
                        OneContext().push(
                          MaterialPageRoute(
                            builder: (_) => Payment(
                              doctorIdSelected: context
                                  .read<DoctorsProvider>()
                                  .doctorIdSelected,
                              doctorNameSelected: context
                                  .read<DoctorsProvider>()
                                  .doctorNameSelected,
                              date: date,
                              selectedTime: _selectedTime.toString(),
                              purpose: purposecontroller.text.trim(),
                              name: namecontroller.text.trim(),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 3),
                  Flexible(
                    child: CustomButton(
                      text: "Confirm by code",
                      onTap: () {
                        String date =
                            convertDateTimeDisplay(_selectedDate.toString());
                        OneContext().showDialog(
                          // barrierDismissible: false,
                          builder: (_) => AlertDialog(
                            title: const Text("Enter code"),
                            content: TextField(
                              controller: codeController,
                              maxLength: 8,
                            ),
                            actions: [
                              TextButton(
                                onPressed: () {
                                  if (codeController.text.length == 8 &&
                                      codeController.text.startsWith("Nova")) {
                                    context
                                        .read<AppointmentProvider>()
                                        .checkCode(
                                          codeController.text.trim(),
                                          context
                                              .read<DoctorsProvider>()
                                              .doctorIdSelected,
                                          context
                                              .read<DoctorsProvider>()
                                              .doctorNameSelected,
                                          date,
                                          _selectedTime.toString(),
                                          purposecontroller.text.trim(),
                                          namecontroller.text.trim(),
                                        );
                                    Navigator.of(context, rootNavigator: true)
                                        .pop();
                                  }
                                },
                                child: const Text("Done"),
                              )
                            ],
                          ),
                        );

                        // );
                        // final col =
                        //     FirebaseFirestore.instance.collection("codes");
                        // for (var i = 0; i < 100; i++) {
                        //   String code = getRandomString();
                        //   col.add({"code": "Nova$code"});
                        // }
                      },
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
