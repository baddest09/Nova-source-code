// ignore_for_file: library_private_types_in_public_api

import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_doctor/translations/locale_keys.g.dart';
import 'package:easy_localization/easy_localization.dart';

import 'package:flutter/material.dart';

class Department {
  String image;
  String? title;
  int doctors;
  Department(this.image, this.title, this.doctors);
}

class OurDepartments extends StatefulWidget {
  const OurDepartments({super.key});

  @override
  _OurDepartmentsState createState() => _OurDepartmentsState();
}

class _OurDepartmentsState extends State<OurDepartments> {
  @override
  Widget build(BuildContext context) {
    List<Department> departments = [
      Department('assets/departments/dep1.png', LocaleKeys.oncologyDep.tr(), 6),
      Department(
          'assets/departments/dep2.png', LocaleKeys.ophthalmologyDep.tr(), 6),
      Department(
          'assets/departments/dep3.png', LocaleKeys.pediatricDep.tr(), 6),
      Department('assets/departments/dep4.png', LocaleKeys.ctScan.tr(), 6),
      Department(
          'assets/departments/dep5.png', LocaleKeys.cardiologyDep.tr(), 6),
      Department(
          'assets/departments/dep6.png', LocaleKeys.orthopedicDep.tr(), 6),
      Department(
          'assets/departments/dep7.png', LocaleKeys.gynecologyDep.tr(), 6),
      Department('assets/departments/dep1.png', LocaleKeys.oncologyDep.tr(), 6),
      Department(
          'assets/departments/dep2.png', LocaleKeys.ophthalmologyDep.tr(), 6),
      Department(
          'assets/departments/dep3.png', LocaleKeys.pediatricDep.tr(), 6),
      Department('assets/departments/dep4.png', LocaleKeys.ctScan.tr(), 6),
      Department(
          'assets/departments/dep5.png', LocaleKeys.cardiologyDep.tr(), 6),
      Department(
          'assets/departments/dep6.png', LocaleKeys.orthopedicDep.tr(), 6),
      Department(
          'assets/departments/dep7.png', LocaleKeys.gynecologyDep.tr(), 6),
    ];
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.chevron_left)),
        centerTitle: true,
        title: Text(
          LocaleKeys.ourDep.tr(),
        ),
      ),
      body: FadedSlideAnimation(
        beginOffset: const Offset(0, 0.3),
        endOffset: const Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
        child: ListView.builder(
            itemCount: departments.length,
            itemBuilder: (context, index) {
              return Column(
                children: [
                  const Divider(
                    thickness: 6,
                    height: 6,
                  ),
                  ListTile(
                    onTap: () {
                      // Navigator.pushNamed(
                      //     context, PageRoutes.doctorDepartmentsPage);
                    },
                    leading: Image.asset(departments[index].image),
                    title: Text(
                      departments[index].title!,
                      style: Theme.of(context).textTheme.bodyText1!.copyWith(
                            fontSize: 16,
                          ),
                    ),
                    subtitle: Text(
                        '${departments[index].doctors} ${LocaleKeys.doctors.tr()}'),
                  )
                ],
              );
            }),
      ),
    );
  }
}
